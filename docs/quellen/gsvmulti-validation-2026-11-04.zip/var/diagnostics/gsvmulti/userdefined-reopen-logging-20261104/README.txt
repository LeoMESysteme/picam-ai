GSVmulti UserDefined close/reopen logging evidence, 2026-11-04

Environment: Windows11, UI GSVmulti2.03 Pro, EXE FileVersion2.3.4;
MEGSV.dll FileVersion1.62.0.64/ProductVersion1.62.0.0 (full inventory included).
Direct FTDI COM4,115200,8N1, one UserDefined channel, percent prefix,
Filter Out Non-Numeric on,10Hz,mV/V. No sender active during this reproduction.
User starts GSVmulti without channel, then manually loads known working session.
LogLevel=2 configured after full exit with original config backup retained.
User instructed Device Close once, reopen same COM4 profile, leave app running.

Observed in user-pasted log excerpt:
- Open Session UserDevice COM4 channel1 Fdata10,000.
- 0xFFFFFFFF in GS Vclear Buffer.vi already at initial session load.
- Two subsequent 0x300000F6 already-open failures through GS Vactivate
  Extended.vi/OpenDevice2.vi/OpenSession.vi. Screenshot confirms COM4 already open.
- No explicit Close/deactivate trace is present in supplied excerpt.

The full original Windows log was not uploaded; this is a pasted excerpt.
External timestamp strings have no verified project TimeBaseKind/uncertainty.
Do not derive latency or operation intervals from them.
Generic -1 does not identify a timeout, empty buffer, invalid argument or driver cause.
No causal link between clear-buffer and reopen error is established.
Prior external COM4 probes denied during failed GSV process, succeeded after exit.
This package contains no raw DLLs and makes no claim which module owns a handle.

Next comparison (not run): restart empty, create same UserDefined profile through
Add Channel rather than session load; Close once and reopen via Add Channel,
then inspect newest log. Expected no-sender numeric timeout is separate from
activation/clear-buffer failures. Real DUT output remains locked.

Reference for GSVclearBuffer: official ba-megsv-v2.0.pdf p171,
https://www.me-systeme.de/produkte/software/megsv/ba-megsv-v2.0.pdf
Older GSV2/3 API documentation; not proof of current UserDefined internals.
No external contact or message has been sent.
