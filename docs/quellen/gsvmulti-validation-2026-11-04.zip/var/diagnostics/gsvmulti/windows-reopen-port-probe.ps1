﻿& {
    $gsvProbe = [System.IO.Ports.SerialPort]::new('COM4', 115200, 'None', 8, 'One')
    $gsvProbe.Handshake = 'None'
    try {
        $gsvProbe.Open()
        Write-Host 'COM4: Öffnen erfolgreich; Port wird sofort wieder geschlossen.'
    }
    catch {
        $gsvProbeError = $_.Exception.GetBaseException()
        Write-Host ('COM4: {0}: {1}' -f $gsvProbeError.GetType().Name, $gsvProbeError.Message)
    }
    finally {
        $gsvProbe.Dispose()
    }
}
