# Direkte USB-Anbindung an GSVmulti: Untersuchung vom 2026-11-04

Stand: Umsetzungsvorschlag, kein installierter oder abgenommener USB-Weg.
Nutzerauftrag: konkrete Umsetzbarkeit prüfen. Keine Boot-/Modul-/Stromänderung,
keine Installation, kein Reboot und kein aktiver USB-Test ausgeführt.

## Ergebnis und Aufbau

Empfohlene Datenfunktion: ein serielles CDC-ACM-Gadget am Pi5-USB-C-Port.
Pi-Demo/TelegramFormatter -> /dev/ttyGS0 -> USB -> Windows COMx -> GSVmulti
UserDefined. Die COM-Nummer wird bei der Windows-Erkennung ermittelt, nicht
vorab angenommen. Für diesen direkten Weg weder com0com noch Windows-Brücke.
USB-Ethernet wäre eine Alternative für SSH/TCP, erzeugt aber keinen seriellen
GSVmulti-COM-Port und beseitigt dessen VCOM-Bedarf nicht von selbst.

## Lokal nachgewiesen

- Pi5 ModelB Rev1.1, Kernel6.12.34+rpt-rpi-2712, Debian13.
- dwc2 builtin; libcomposite,usb_f_acm,g_serial als vorhandene Module gefunden.
- configfs gemountet, aber kein aktives Gadget-Verzeichnis und kein UDC sichtbar.
- serial-getty@ttyGS0 disabled; keine ttyGS0-Konsole im Boot-cmdline.
- dwc2 dr_mode=host steht unter cm5, ist keine aktive Pi5-Host-Konfiguration.
- Logitech StreamCam und PL2303-Referenzadapter sind als USB-Geräte vorhanden.
- Firmwareabfragen get_throttled/usb_max_current_enable scheitern wegen fehlendem
  Zugriff auf /dev/vcio_gencmd; kein Strombudget oder Unterspannungszustand gemessen.

## Stromversorgung: entscheidende Einschränkung

Nutzer: X1201 V1.1 von SupTronics, lädt am eigenen USB-C; Produktion eventuell
ohne UPS. Hersteller: Versorgung des Pi über pogo pins,5.1V/max5A, aber
zusätzliche Versorgung über Pi-USB-C ausdrücklich untersagt. Deshalb ist der
normale PC-USB-Anschluss parallel zur UPS nicht als Testaufbau freigegeben.

Für bestehenden UPS-Aufbau kommt als Kandidat eine USB2-Datenstrecke mit
unterbrochenem VBUS infrage: D+/D-/GND bleiben verbunden, Host-5V wird nicht
an Pi-USB-C geführt. Es gibt USB-Power-Blocker mit genau dieser Belegung,
z.B. PortaPow PPUSBBP1. Der Hersteller sagt ausdrücklich, dass viele Geräte
bei unterbrochenem VBUS nicht mehr kommunizieren; ein solcher Adapter ist
kein Kompatibilitätsnachweis für Pi5/X1201. Daher zuerst Schaltung/Erkennung
prüfen, keine pauschale Kauf-/Funktionszusage. Ein Data Blocker wäre das
Gegenteil und würde die gewünschte Datenverbindung unterbrechen.

Für Produktion ohne UPS bleibt die Software gleich, die Versorgung muss aber
separat festgelegt werden: ein nachweislich ausreichender PC-USB-Versorgungsweg
oder eine geeignete externe Versorgung mit sauber getrennter Stromführung.
Raspberry Pi empfiehlt5V/5A; mit5V/3A wird USB-Peripherie standardmäßig auf
insgesamt600mA begrenzt. Hohe USB-PD-Wattangabe allein beweist kein5V/5A-Profil.
Ein beliebiger aktiver Hub, Y-Adapter oder Pi4-Splitter ist kein Nachweis für
diesen Aufbau mit StreamCam. Keine Stromgrenzen per Software überbrücken,
solange tatsächliche Versorgung/Last nicht geprüft ist.

## Vorgeschlagene Einrichtung nach Klärung des Stromwegs

1. Firmware-config sichern, unterscheidbaren Pi5-wirksamen
   dtoverlay=dwc2,dr_mode=peripheral-Eintrag ergänzen; vorhandene cm4/cm5-
   Abschnitte, Kamera/UART/PCIe und cmdline erhalten. Geplanter Neustart,
   SSH über vorhandenes LAN/WLAN weiter als Zugang benutzen.
2. Nach Neustart genau einen passenden UDC nachweisen. libcomposite laden,
   ConfigFS-Gadget mit genau einer acm.usb0-Funktion anlegen. Für Windows-
   Bindung CDC-Klassenkennung/Deskriptoren, stabile Seriennummer und passende
   VID/PID-Herkunft explizit festlegen. Keine native GSV-Gerätekennung imitieren.
   Keine Login-Konsole auf ttyGS0. Erst an UDC binden, wenn Aufbau geprüft.
3. Windows muss COMx mit Usbser.sys und StatusOK erkennen; tatsächlich geladene
   Kennungen/Treiber erfassen. Keine com0com-Installation für diesen Weg nötig.
4. Bestehenden endlichen Demo-Sender wiederverwenden, ohne Produktsperren zu
   verändern. Bereits vorhandene CLI akzeptiert --demo --com-port /dev/ttyGS0.
   Nach Erscheinen des Ports und Anlegen eines neuen Diagnoseverzeichnisses z.B.:

   ./.venv/bin/python scripts/gsv-bridge.py --demo --com-port /dev/ttyGS0 --count 600 --rate-hz 10 --log var/diagnostics/gsvmulti/<neuer-lauf>/tx.jsonl

   Dieser Aufruf ist noch NICHT ausgeführt. Die Portoption heißt im alten
   CLI com-port, funktioniert technisch über pySerial auch mit Linux-TTY-Pfad;
   die Hilfetexte sind bislang Windows-orientiert.
5. Frisch gestartetes GSVmulti: UserDefined, neuer COMx,115200,ein Wert,
   Präfix%,Zahlenfilter ein,10Hz,mV/V. Gültige synthetische Folge in TDMS/TXT
   vergleichen. Treiber-Schreibbestätigungen sind kein Empfängerbeweis.
   SYNTHETIC-Aufnahmezeit liefert keine Latenzaussage. Danach Kamera-/USB-
   Versorgung unter Last und Trennen/Wiederverbinden getrennt prüfen.
6. Erst nach erstem Erfolg feste Start-/Stop-Einrichtung per systemd/udev,
   reversibler Installer und spätere Setup-TUI. Keine sofortige Live-Integration:
   OutputConfig erlaubt derzeit nur off/uart/tcp und bindet UART an ttyAMA0.
   USB müsste ausdrücklich ergänzt werden; diese Begrenzung nicht aufweichen,
   Referenzport ttyUSB0 bleibt getrennt. Echte DUT-Ausgabesperre bleibt erhalten.

## Softwarealternativen und Empfehlung

- ConfigFS/acm.usb0: empfohlen für kontrollierte Deskriptoren, Identität und
  sauberes Unbind/Cleanup, später als eigener Dienst. Etwas mehr Einrichtung.
- Legacy g_serial: Modul vorhanden, kurzer Funktionstest möglich; weniger
  Kontrolle und bestehende Standarddeskriptoren nicht mit bestätigter Windows-
  Bindung verwechseln. Nicht gleichzeitig mit ConfigFS-Gadget aktivieren.
- USB-Ethernet/rpi-usb-gadget: geeignet für USB-Netz/SSH, aber kein direkter
  serieller GSVmulti-Ersatz. Für dieses Ziel zusätzlicher Brückenbedarf.

## Rückbau und unveränderte Abnahmegrenzen

Gadget gezielt vom UDC lösen, nur eigene Funktion/Konfiguration entfernen,
späteren Dienst deaktivieren, eigene Bootänderung nach kontrolliertem Vergleich
zurücknehmen und bei Bedarf neu starten. Keine globalen USB-Hostmodule entfernen,
weil Kamera/Referenz darüber laufen. Bestehende Referenz und UART-Belege erhalten.
USB behebt weder GSVmulti-Close/ClearBuffer-Fehler noch fehlende Ungültigzeiträume.
Nur gültige synthetische Demos; echte DUT-Ausgabe bleibt strukturell gesperrt.

## Quellen

- Raspberry Pi OTG-Whitepaper (Pi4/5,CDC ACM):
  https://pip-assets.raspberrypi.com/categories/685-app-notes-guides-whitepapers/documents/RP-009276-WP-1-Using%20OTG%20mode%20on%20Raspberry%20Pi%20SBCs
- Linux ConfigFS-Aufbau/Unbind/Cleanup:
  https://docs.kernel.org/usb/gadget_configfs.html
- Microsoft Usbser-Klassenbindung:
  https://learn.microsoft.com/en-us/windows-hardware/drivers/usbcon/usb-driver-installation-based-on-compatible-ids
- Exaktes X1201-V1.1-Modell,Specs und Pi-USB-C-Einschränkung:
  https://suptronics.com/Raspberrypi/Power_mgmt/x1201-v1.1.html
- Pi5-Versorgungs-/Peripheriebudget:
  https://www.raspberrypi.com/documentation/computers/getting-started.html#power-supply
- Power-Blocker-Funktion UND Kompatibilitätsgrenze:
  https://portablepowersupplies.co.uk/product/usb-power-blocker
