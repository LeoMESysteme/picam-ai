﻿& {
    $ErrorActionPreference = 'Stop'
    $gsvTrialDir = Join-Path ([System.IO.Path]::GetTempPath()) ('gsv-com0com-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $gsvTrialDir | Out-Null
    $gsvSetup = Join-Path $gsvTrialDir 'com0com-vovsoft.exe'
    $gsvUrl = 'https://raw.githubusercontent.com/vovsoft/com0com/main/com0com%20v.3.0.0%20setup%2032%2B64-bit%20signed.exe'
    Invoke-WebRequest -UseBasicParsing -Uri $gsvUrl -OutFile $gsvSetup
    $gsvExpected = 'AE0DD19472F92BAB3165D370C3713616A3FFB708FAD785684759B04653705A71'
    if ((Get-FileHash -LiteralPath $gsvSetup -Algorithm SHA256).Hash -ne $gsvExpected) {
        throw 'Download weicht vom geprueften Paket ab. Setup nicht gestartet.'
    }
    "Geprueftes Setup: $gsvSetup"
    Start-Process -FilePath $gsvSetup -Verb RunAs -Wait
    Get-CimInstance Win32_PnPEntity |
        Where-Object { $_.Name -match 'com0com' } |
        Select-Object Name, ConfigManagerErrorCode |
        Format-List
    Get-CimInstance Win32_PnPSignedDriver |
        Where-Object { $_.DeviceName -match 'com0com' } |
        Select-Object DeviceName, DriverVersion, InfName, IsSigned, Signer |
        Format-List
}
