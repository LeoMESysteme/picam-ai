﻿& {
    pnputil /enum-devices /instanceid 'ROOT\COM0COM\0000' /drivers

    Get-CimInstance Win32_SystemDriver -Filter "Name='com0com'" |
        Select-Object Name, State, PathName |
        Format-List

    $gsvCi = @(Get-WinEvent -FilterHashtable @{
        LogName = 'Microsoft-Windows-CodeIntegrity/Operational'
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 2000 -ErrorAction Stop |
        Where-Object { $_.Message -match 'com0com' } |
        Select-Object -First 6)

    if ($gsvCi.Count -eq 0) {
        'Kein com0com-Treffer im gelesenen CodeIntegrity-Ausschnitt.'
    } else {
        $gsvCi | Select-Object TimeCreated, Id, Message | Format-List
    }
}
