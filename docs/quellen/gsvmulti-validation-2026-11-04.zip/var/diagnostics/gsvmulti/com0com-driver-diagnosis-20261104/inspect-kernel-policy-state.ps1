﻿& {
    Get-CimInstance Win32_OperatingSystem |
        Select-Object Caption, Version, BuildNumber |
        Format-List

    try {
        "Secure Boot: $(Confirm-SecureBootUEFI -ErrorAction Stop)"
    } catch {
        "Secure-Boot-Abfrage: $($_.Exception.Message)"
    }

    Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard |
        Select-Object VirtualizationBasedSecurityStatus,
            SecurityServicesConfigured, SecurityServicesRunning,
            CodeIntegrityPolicyEnforcementStatus |
        Format-List
}
