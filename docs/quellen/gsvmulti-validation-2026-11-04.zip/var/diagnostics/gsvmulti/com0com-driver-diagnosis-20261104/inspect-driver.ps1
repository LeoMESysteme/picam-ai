﻿& {
    Get-CimInstance Win32_PnPEntity |
        Where-Object { $_.Name -match 'com0com' -or $_.PNPDeviceID -like 'ROOT\COM0COM\*' } |
        Select-Object Name, PNPDeviceID, Service, ConfigManagerErrorCode |
        Format-List

    Get-CimInstance Win32_PnPSignedDriver |
        Where-Object { $_.DeviceName -match 'com0com' -or $_.DeviceID -like 'ROOT\COM0COM\*' } |
        Select-Object DeviceName, DeviceID, DriverVersion, DriverProviderName, InfName, IsSigned, Signer |
        Format-List
}
