﻿& {
    $ErrorActionPreference = 'Stop'
    $gsvRoot = Join-Path $env:USERPROFILE ('gsvmulti-demo-' + [guid]::NewGuid().ToString('N').Substring(0,8))
    New-Item -ItemType Directory -Path $gsvRoot | Out-Null
    $gsvZip = Join-Path $gsvRoot 'bridge.zip'
    scp me-systeme@100.122.154.35:/home/me-systeme/picam-ai/var/exports/gsvmulti-windows-com5-com6-2026-11-04.zip $gsvZip
    if ($LASTEXITCODE -ne 0) { throw 'SSH-Uebertragung fehlgeschlagen.' }
    $gsvExpected = 'B91053BF47AFBE6ADAE778A8B3AD85908A6B8422A2083ECDF38097FD7A14069F'
    if ((Get-FileHash -LiteralPath $gsvZip -Algorithm SHA256).Hash -ne $gsvExpected) {
        throw 'Paketpruefsumme stimmt nicht.'
    }
    $gsvApp = Join-Path $gsvRoot 'bridge'
    Expand-Archive -LiteralPath $gsvZip -DestinationPath $gsvApp
    py -3.15 -m venv --system-site-packages "$gsvApp\.venv"
    if ($LASTEXITCODE -ne 0) { throw 'Python-Umgebung konnte nicht erstellt werden.' }
    $gsvPython = Join-Path $gsvApp '.venv\Scripts\python.exe'
    & $gsvPython -m pip install --no-deps pyserial==3.5
    if ($LASTEXITCODE -ne 0) { throw 'pySerial-Installation fehlgeschlagen.' }
    & $gsvPython (Join-Path $gsvApp 'gsv-bridge.py') --help
    if ($LASTEXITCODE -ne 0) { throw 'Bruecke konnte nicht starten.' }
    "Brueckenordner: $gsvApp"
}
