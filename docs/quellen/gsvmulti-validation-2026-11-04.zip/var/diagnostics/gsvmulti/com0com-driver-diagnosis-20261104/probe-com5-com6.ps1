﻿& {
    $gsvA = [System.IO.Ports.SerialPort]::new('COM5',115200,'None',8,'One')
    $gsvB = [System.IO.Ports.SerialPort]::new('COM6',115200,'None',8,'One')
    try {
        foreach ($gsvPort in @($gsvA, $gsvB)) {
            $gsvPort.NewLine = "`r`n"
            $gsvPort.ReadTimeout = 2000
            $gsvPort.WriteTimeout = 2000
        }
        $gsvA.Open()
        $gsvB.Open()
        $gsvA.DiscardInBuffer()
        $gsvB.DiscardInBuffer()

        $gsvA.WriteLine('%+000.125')
        if ($gsvB.ReadLine() -cne '%+000.125') { throw 'COM5 -> COM6: falsche Daten' }
        'COM5 -> COM6: OK'

        $gsvB.WriteLine('%-000.625')
        if ($gsvA.ReadLine() -cne '%-000.625') { throw 'COM6 -> COM5: falsche Daten' }
        'COM6 -> COM5: OK'
    } finally {
        $gsvA.Dispose()
        $gsvB.Dispose()
    }

    "Secure Boot: $(Confirm-SecureBootUEFI)"
    Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard |
        Select-Object SecurityServicesRunning, CodeIntegrityPolicyEnforcementStatus |
        Format-List
    $gsvNative = if ([Environment]::Is64BitProcess) { 'System32' } else { 'Sysnative' }
    Get-FileHash -LiteralPath "$env:windir\$gsvNative\drivers\com0com.sys" -Algorithm SHA256 |
        Format-List
}
