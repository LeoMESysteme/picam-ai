﻿& {
    $gsvSystemDir = if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) {
        "$env:windir\Sysnative"
    } else {
        "$env:windir\System32"
    }
    $gsvDriver = Join-Path $gsvSystemDir 'drivers\com0com.sys'

    Get-FileHash -LiteralPath $gsvDriver -Algorithm SHA256 -ErrorAction Stop |
        Format-List

    Get-AuthenticodeSignature -LiteralPath $gsvDriver |
        Select-Object Path, Status, StatusMessage,
            @{Name='Signer'; Expression={$_.SignerCertificate.Subject}} |
        Format-List
}
