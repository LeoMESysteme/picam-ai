﻿& {
    $gsvCi = @(Get-WinEvent -FilterHashtable @{
        LogName = 'Microsoft-Windows-CodeIntegrity/Operational'
        StartTime = (Get-Date).AddDays(-7)
    } -MaxEvents 2000 -ErrorAction Stop |
        Where-Object { $_.Message -match 'com0com' } |
        Select-Object -First 8)
    if ($gsvCi.Count -eq 0) {
        'Kein com0com-Treffer im gelesenen CodeIntegrity-Ausschnitt.'
    } else {
        $gsvCi | Select-Object TimeCreated, Id, Message | Format-List
    }
}
