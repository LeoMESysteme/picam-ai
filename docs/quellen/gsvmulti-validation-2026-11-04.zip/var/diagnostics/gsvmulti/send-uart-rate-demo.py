"""Local experiment recipe; uses the project's existing synthetic demo sender."""
from pathlib import Path
from dataclasses import asdict
from datetime import UTC, datetime
import argparse
import hashlib
import json
import time
import serial
from dispread.gsv_bridge import send_demo
from dispread.records import TimeBaseKind
from dispread.sink.protocol.user_defined import UserDefinedFormatter

parser = argparse.ArgumentParser()
parser.add_argument('--count', type=int, default=600)
args = parser.parse_args()
base = Path('var/diagnostics/gsvmulti')
for number in range(1, 1000):
    run = base / f'uart-direct-demo-20261104-{number:02d}'
    try:
        run.mkdir(parents=True, exist_ok=False)
        break
    except FileExistsError:
        continue
else:
    raise RuntimeError('No unused run directory')
caps = asdict(UserDefinedFormatter().capabilities)
caps['supported_invalid_policies'] = sorted(caps['supported_invalid_policies'])
meta = dict(schema='gsv-uart-demo/v1', demo=True, provisional=True,
    transport='uart_direct', port='/dev/ttyAMA0', receiver_port_reported='COM4',
    baudrate=115200, bytesize=8, parity='N', stopbits=1, handshake=False,
    source_time_base=TimeBaseKind.SYNTHETIC.value,
    transmit_time_base=TimeBaseKind.HOST_MONOTONIC.value,
    count_requested=args.count, target_rate_hz=10, formatter_capabilities=caps,
    state='starting', sent_driver_records=0, receiver_evidence=None,
    started_at_utc=datetime.now(UTC).isoformat(),
    procedure='Controlled rate comparison: same 600-record ramp as run 05. User reports GSVmulti data rate changed from 1 Hz to 10 Hz. Filter/record-every-value/tab-separated auto-export instructed unchanged. Sender first, then connect/start measuring and recording; exact recording start not independently logged.',
    receipt_scope='Pi UART driver accepted bytes; not proof of GSVmulti reception',
    time_claim='Host sender runtime only; no sensor latency or synchronization claim')
paths = [Path(__file__), Path('src/dispread/gsv_bridge.py'),
         Path('src/dispread/sink/protocol/user_defined.py'), Path('src/dispread/records.py')]
meta['source_sha256'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
path = run / 'session.json'
def save():
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(meta, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)
save()
print(f'RUN_DIR={run.resolve()}', flush=True)
started = time.monotonic_ns()
meta['t_sender_start_ns'] = started
try:
    with (run / 'tx.jsonl').open('x', encoding='utf-8') as log:
        with serial.Serial('/dev/ttyAMA0', baudrate=115200, bytesize=8,
                           parity=serial.PARITY_NONE, stopbits=1, timeout=.1,
                           write_timeout=1, xonxoff=False, rtscts=False,
                           dsrdtr=False, exclusive=True) as port:
            meta['state'] = 'sending'
            save()
            print(f'SENDER RUNNING: {args.count} synthetic records, target 10 Hz.', flush=True)
            send_demo(port, count=args.count, rate_hz=10, log=log,
                      completion_stage='pi_uart_driver_write')
    meta['state'] = 'sender_completed'
except BaseException as exc:
    meta['state'] = 'sender_failed'
    meta['error'] = f'{type(exc).__name__}: {exc}'
    raise
finally:
    meta['t_sender_end_ns'] = time.monotonic_ns()
    meta['sender_runtime_s'] = (meta['t_sender_end_ns'] - started) / 1e9
    meta['ended_at_utc'] = datetime.now(UTC).isoformat()
    log_path = run / 'tx.jsonl'
    if log_path.exists():
        events = [json.loads(line) for line in log_path.read_text().splitlines() if line.strip()]
        meta['sent_driver_records'] = len(events)
        meta['bytes_driver_accepted'] = sum(len(bytes.fromhex(e['wire_bytes_hex'])) for e in events)
        meta['first_wire_bytes_hex'] = events[0]['wire_bytes_hex'] if events else None
        meta['last_wire_bytes_hex'] = events[-1]['wire_bytes_hex'] if events else None
        meta['tx_log_sha256'] = hashlib.sha256(log_path.read_bytes()).hexdigest()
    save()
    print(json.dumps(meta, indent=2), flush=True)
