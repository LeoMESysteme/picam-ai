"""Local TCP-only diagnostic precheck; no Windows or serial hardware evidence."""
from pathlib import Path
import io
import json
import socket
import subprocess
import sys
import time

from dispread.gsv_bridge import BridgeSession, _Link

root = Path(__file__).resolve().parent
run = root / 'tcp-reconnect-precheck-20261104-01'
run.mkdir(exist_ok=False)
with socket.socket() as probe:
    probe.bind(('127.0.0.1', 0))
    port = probe.getsockname()[1]
process = subprocess.Popen([sys.executable, str(root / 'reconnect-source-spike.py'),
                            '--host', '127.0.0.1', '--port', str(port),
                            '--count', '100', '--rate-hz', '50', '--connect-timeout', '5',
                            '--out-dir', str(run / 'pi-publisher')],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
connection = None

class MemoryCom:
    def write(self, data):
        return len(data)

def connect():
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        try:
            return socket.create_connection(('127.0.0.1', port), timeout=.5)
        except OSError:
            time.sleep(.03)
    raise TimeoutError('Precheck connect failed')

try:
    before_log = io.StringIO()
    before = BridgeSession(log=before_log)
    connection = connect()
    link = _Link(connection)
    while sum(json.loads(s).get('outcome') == 'written' for s in before_log.getvalue().splitlines()) < 10:
        before.exchange(link, MemoryCom())
        time.sleep(.005)
    connection.close()
    connection = None
    disconnected_at = time.monotonic_ns()
    time.sleep(.4)
    # TCP publisher retries after one second, while source generation continues.
    connection = connect()
    after_log = io.StringIO()
    after = BridgeSession(log=after_log)
    link = _Link(connection)
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        after.exchange(link, MemoryCom())
        written = [json.loads(s) for s in after_log.getvalue().splitlines() if json.loads(s).get('outcome') == 'written']
        if written and written[-1]['frame_sequence'] == 99:
            break
        time.sleep(.005)
    stdout, stderr = process.communicate(timeout=15)
    assert process.returncode == 0, (stdout, stderr)
    before_events = [json.loads(s) for s in before_log.getvalue().splitlines()]
    after_events = [json.loads(s) for s in after_log.getvalue().splitlines()]
    bw = [e for e in before_events if e['outcome'] == 'written']
    aw = [e for e in after_events if e['outcome'] == 'written']
    records = [json.loads(s) for s in (run / 'pi-publisher' / 'records.jsonl').read_text().splitlines()]
    publications = [json.loads(s) for s in (run / 'pi-publisher' / 'source-events.jsonl').read_text().splitlines()]
    pub_events = [e for e in (json.loads(s) for s in (run / 'pi-publisher' / 'output.jsonl').read_text().splitlines())]
    offers = [e for e in pub_events if e['event'] == 'offered']
    reconnect_offer = next(e for e in offers if e['frame_sequence'] == aw[0]['frame_sequence'])
    during_gap = [e for e in publications if e['event'] == 'publish_complete' and disconnected_at < e['t_ns'] < reconnect_offer['t_ns']]
    assert len(records) == 100 and aw[-1]['frame_sequence'] == 99
    assert len(during_gap) >= 10
    assert aw[0]['frame_sequence'] > bw[-1]['frame_sequence'] + 10
    latest_started = max(e['frame_sequence'] for e in publications if e['event'] == 'publish_start' and e['t_ns'] <= reconnect_offer['t_ns'])
    latest_completed = max(e['frame_sequence'] for e in publications if e['event'] == 'publish_complete' and e['t_ns'] <= reconnect_offer['t_ns'])
    assert latest_completed <= aw[0]['frame_sequence'] <= latest_started
    report = dict(passed=True, scope='local loopback TCP plus memory COM only; no Windows or GSVmulti',
                  demo=True, provisional=True, time_claim=False,
                  count=100, target_rate_hz=50, process_exit_code=process.returncode,
                  last_before=bw[-1]['frame_sequence'], first_after=aw[0]['frame_sequence'],
                  last_after=aw[-1]['frame_sequence'], published_during_gap=len(during_gap),
                  first_after_matches_latest_publication_bounds=True)
    (run / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    (run / 'before.jsonl').write_text(before_log.getvalue())
    (run / 'after.jsonl').write_text(after_log.getvalue())
    (run / 'stdout.txt').write_text(stdout)
    (run / 'stderr.txt').write_text(stderr)
    print(json.dumps(report, indent=2))
finally:
    if connection is not None:
        connection.close()
    if process.poll() is None:
        process.terminate()
        process.wait(timeout=10)
