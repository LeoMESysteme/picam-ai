"""Compare a synthetic step fixture with the user's saved TDMS and text files."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime
import itertools,json,hashlib,shutil,sys
root=Path(__file__).resolve().parent;run=root/'uart-direct-demo-20261104-07'
attachment=Path('/home/me-systeme/.codex/attachments/595198af-f1a0-45e2-ba96-e7ce9ffadd32')
receiver=run/'receiver';receiver.mkdir(exist_ok=True)
files=list(attachment.glob('04_11_26-13_32_40.*'));assert len(files)==3
for p in files:shutil.copy2(p,receiver/p.name)
wheel=next((root/'analysis-tools').glob('nptdms-1.13.0-*.whl'));sys.path.insert(0,str(wheel))
from nptdms import TdmsFile
import numpy as np
rows=[]
for line in (receiver/'04_11_26-13_32_40.txt').read_text(encoding='utf-8-sig').splitlines():
 if line.startswith('04.11.2026 '):
  t,v=line.split('\t');rows.append((datetime.strptime(t.replace(',','.'),'%d.%m.%Y %H:%M:%S.%f'),Decimal(v.replace(',','.'))))
assert rows
values=[v for _,v in rows]
tx=[json.loads(l) for l in (run/'tx.jsonl').read_text().splitlines()]
sent=[Decimal(bytes.fromhex(e['wire_bytes_hex']).decode().strip()[1:]) for e in tx]
f=TdmsFile.read(receiver/'04_11_26-13_32_40.tdms');g=f.groups()[0];c=g.channels()[0]
assert len(f.groups())==1 and len(g.channels())==1
alignments=[i for i in range(len(sent)-len(values)+1) if sent[i:i+len(values)]==values]
blocks=lambda seq:[{'value_decimal':str(v),'count':len(list(items))} for v,items in itertools.groupby(seq)]
steps=lambda seq:[{'index':i,'from_decimal':str(seq[i-1]),'to_decimal':str(seq[i])} for i in range(1,len(seq)) if seq[i]!=seq[i-1]]
text_steps=[(b[0]-a[0]).total_seconds() for a,b in zip(rows,rows[1:])]
float_expected=np.asarray([float(v) for v in values],dtype=np.float64)
result={
 'schema':'gsv-uart-step-comparison/v1','demo':True,'provisional':True,
 'uploaded_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
 'recipe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'reader':{'package':'npTDMS','version':'1.13.0','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'loading':'isolated wheel import, no environment installation','numpy_path':np.__file__},
 'tx_log_sha256':hashlib.sha256((run/'tx.jsonl').read_bytes()).hexdigest(),
 'sender_count':len(sent),'text_count':len(values),'tdms_count':len(c),
 'matching_sender_start_indices':alignments,'text_exact_contiguous_sender_subsequence':bool(alignments),
 'tdms_exact_float64_text_values':bool(np.array_equal(c[:],float_expected)),
 'max_tdms_abs_difference_from_text_float64':float(np.max(np.abs(c[:]-float_expected))) if len(c)==len(values) else None,
 'sender_blocks':blocks(sent),'recorded_blocks':blocks(values),
 'sender_transitions':steps(sent),'recorded_transitions':steps(values),
 'unexpected_value_count':sum(v not in set(sent) for v in values),
 'all_sender_transitions_preserved_in_order':[(Decimal(s['from_decimal']),Decimal(s['to_decimal'])) for s in steps(sent)]==[(Decimal(s['from_decimal']),Decimal(s['to_decimal'])) for s in steps(values)],
 'text_first_time':rows[0][0].isoformat(),'text_last_time':rows[-1][0].isoformat(),
 'text_time_span_s':(rows[-1][0]-rows[0][0]).total_seconds(),
 'text_step_min_s':min(text_steps),'text_step_max_s':max(text_steps),
 'tdms_properties':c.properties,'tdms_group_properties':g.properties,
 'time_scope':{'source_base':'synthetic','sender_events_base':'host_monotonic','receiver_axis':'nominal waveform time grid with host wall-clock origin; not measured source/receipt times','uncertainty_ns':None},
 'limits':['Initial manual recording boundary unknown','Repeated plateau values cannot expose compensating losses and repetitions','No real DUT, invalid/stale, outage or common Windows bridge acceptance','No latency or synchronization measurement']}
if len(alignments)==1:
 i=alignments[0];j=i+len(values)-1
 result.update(matched_sender_first_index_zero_based=i,matched_sender_last_index_zero_based=j,omitted_prefix_count=i,omitted_suffix_count=len(sent)-j-1,sender_matched_event_span_s=(tx[j]['t_ns']-tx[i]['t_ns'])/1e9)
 result['tdms_exact_float64_sender_subsequence']=bool(np.array_equal(c[:],np.asarray([float(v) for v in sent[i:j+1]])))
(run/'recording-comparison.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,default=str,allow_nan=False)+'\n')
meta_path=run/'session.json';m=json.loads(meta_path.read_text());m['receiver_evidence']={'kind':'uploaded_tdms_and_text','comparison':'recording-comparison.json','count':len(values),'exact_sender_subsequence':bool(alignments),'all_8_transitions_preserved':result['all_sender_transitions_preserved_in_order'],'scope':'Recorded step sequence and block lengths compared; nominal time grid, no timing or whole-run losslessness claim'};meta_path.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('uploaded_sha256','recipe_sha256','reader','tx_log_sha256','sender_transitions','recorded_transitions')},indent=2,default=str))
assert result['text_exact_contiguous_sender_subsequence']
assert result['tdms_exact_float64_text_values']
assert result.get('tdms_exact_float64_sender_subsequence')
assert result['all_sender_transitions_preserved_in_order']
assert result['unexpected_value_count']==0
assert result['tdms_properties']['dt mode']=='1/f0' and result['tdms_properties']['wf_increment']==0.1
assert min(text_steps)==max(text_steps)==0.1
