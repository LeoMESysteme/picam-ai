& {
    $ErrorActionPreference = 'Stop'
    if (Get-Process -Name 'GSVmulti*' -ErrorAction SilentlyContinue) {
        throw 'Bitte GSVmulti zuerst vollstaendig beenden.'
    }
    $gsvCfg = 'C:\ProgramData\MEsystemeGSVmulti\config.ini'
    $gsvEncoding = [System.Text.Encoding]::GetEncoding(28591)
    $gsvText = $gsvEncoding.GetString([System.IO.File]::ReadAllBytes($gsvCfg))
    if ($gsvText -match '(?m)^\s*LogLevel\s*=') {
        throw 'LogLevel ist bereits vorhanden. Bitte aktuellen Eintrag melden.'
    }
    $gsvHeaders = [regex]::Matches($gsvText, '(?m)^(?:\xEF\xBB\xBF)?[ \t]*\[Config\][ \t]*\r?\n')
    if ($gsvHeaders.Count -ne 1) {
        throw 'Config-Abschnitt nicht eindeutig lesbar. Datei wurde nicht geaendert.'
    }
    $gsvHeader = $gsvHeaders[0]
    $gsvNewline = if ($gsvHeader.Value.EndsWith("`r`n")) { "`r`n" } else { "`n" }
    $gsvBackup = $gsvCfg + '.bak-' + [guid]::NewGuid().ToString('N')
    Copy-Item -LiteralPath $gsvCfg -Destination $gsvBackup -ErrorAction Stop
    $gsvUpdated = $gsvText.Insert($gsvHeader.Index + $gsvHeader.Length, 'LogLevel = 2' + $gsvNewline)
    [System.IO.File]::WriteAllBytes($gsvCfg, $gsvEncoding.GetBytes($gsvUpdated))
    "Sicherung: $gsvBackup"
    'Gesetzt: [Config] LogLevel = 2'
}
