"""Link the reconnect experiment's receiver files, Windows processes and Pi audit."""
from pathlib import Path
from datetime import datetime
from decimal import Decimal
import collections
import hashlib
import json
import shutil
import sys

root = Path(__file__).resolve().parent
run = root / 'tcp-reconnect-20261104-01'
pub = run / 'pi-publisher'
for attachment, dest in [
    ('eb580785-8337-42c5-8966-ccf5f00a6c2e', 'receiver'),
    ('49da568b-436d-46ed-82f2-4eb9d4155ee1', 'windows'),
]:
    destination = run / dest
    destination.mkdir(exist_ok=True)
    for source in (Path('/home/me-systeme/.codex/attachments') / attachment).iterdir():
        target = destination / source.name
        if target.exists():
            assert target.read_bytes() == source.read_bytes()
        else:
            shutil.copy2(source, target)

def lines(path):
    return [json.loads(s) for s in path.read_text(encoding='utf-8-sig').splitlines() if s.strip()]

source_report = json.loads((run / 'source-audit-comparison.json').read_text())
records = lines(pub / 'records.jsonl')
events = lines(pub / 'output.jsonl')
offers = [e for e in events if e['event'] == 'offered']
acks = [e for e in events if e['event'] == 'ack']
before_events = lines(run / 'windows' / 'before.jsonl')
after_events = lines(run / 'windows' / 'after.jsonl')
before = [e for e in before_events if e['outcome'] == 'written']
after = [e for e in after_events if e['outcome'] == 'written']
writes = before + after
control = lines(run / 'windows' / 'control.jsonl')
summary = json.loads((run / 'windows' / 'summary.json').read_text())
assert summary['completed'] is True and summary['demo'] is True and summary['provisional'] is True
assert (run / 'windows' / 'controller-copy.py').read_bytes() == (root / 'windows-reconnect-spike.py').read_bytes()
assert len(writes) == len(offers) == len(acks) == 510
assert len(before) == 100 and len(after) == 410
for offer, ack, write in zip(offers, acks, writes):
    for key in ('request_id', 'run_id', 'frame_sequence', 'barrier_id'):
        assert offer[key] == ack[key] == write[key]
    assert write['completion_stage'] == 'com_driver_write' and write['provisional'] is True
    assert write['time_base'] == 'host_monotonic' and write['outcome'] == 'written'
wire = [bytes.fromhex(e['wire_bytes_hex']) for e in writes]
assert wire == [('%' + records[e['frame_sequence']]['raw_text'] + '\r\n').encode('ascii') for e in writes]
expected = [Decimal(records[e['frame_sequence']]['raw_text']) for e in writes]
rows = []
for line in (run / 'receiver' / '04_11_26-17_41_04.txt').read_text(encoding='utf-8-sig').splitlines():
    if line.startswith('04.11.2026 '):
        t, v = line.split('\t')
        rows.append((datetime.strptime(t.replace(',', '.'), '%d.%m.%Y %H:%M:%S.%f'), Decimal(v.replace(',', '.'))))
values = [v for t, v in rows]
assert values == expected and len(values) == len(set(values)) == 510
wheel = next((root / 'analysis-tools').glob('nptdms-1.13.0-*.whl'))
sys.path.insert(0, str(wheel))
from nptdms import TdmsFile
import numpy as np
tdms = TdmsFile.read(run / 'receiver' / '04_11_26-17_41_04.tdms')
assert len(tdms.groups()) == 1 and len(tdms.groups()[0].channels()) == 1
c = tdms.groups()[0].channels()[0]
data = c[:]
assert len(data) == 510 and np.array_equal(data, np.asarray([float(v) for v in expected]))
assert np.isfinite(data).all()
assert c.properties['unit_string'] == c.properties['NI_UnitDescription'] == 'mV/V'
assert c.properties['Scaling'] == 1 and c.properties['Frequency'] == 10 and c.properties['DevComNo'] == 6
assert before[-1]['frame_sequence'] == 99 and after[0]['frame_sequence'] == 189 and after[-1]['frame_sequence'] == 599
assert values[99:101] == [Decimal('-.201'), Decimal('-.111')]
assert all((b[0] - a[0]).total_seconds() == .1 for a, b in zip(rows, rows[1:]))
assert all(e['outcome'] in ('written', 'idle', 'ended') for e in after_events)
first_before_index = before_events.index(before[0])
assert all(e['outcome'] in ('written', 'idle') for e in before_events[first_before_index:])
pause_start = next(e for e in control if e['event'] == 'pause_started')
pause_end = next(e for e in control if e['event'] == 'pause_finished')
started = [e for e in control if e['event'] == 'bridge_started']
exited = [e for e in control if e['event'] == 'bridge_exited']
assert len(started) == len(exited) == 2 and started[0]['pid'] != started[1]['pid']
assert {e['pid'] for e in started} == {e['pid'] for e in exited}
assert all(e['exit_code'] == 1 for e in exited)  # Both intentional TerminateProcess calls.
report = dict(
    schema='gsv-tcp-reconnect-receiver-comparison/v1', all_comparison_assertions_passed=True,
    demo=True, provisional=True, time_claim=False, run_id=source_report['run_id'],
    source_count=600, source_offered_count=510, source_written_ack_count=510,
    windows_written_before=100, windows_written_after=410, windows_written_total=510,
    text_count=len(values), tdms_count=len(data), all_payloads_byte_exact=True,
    all_requests_run_frames_linked=True, text_and_tdms_match_all_written_values=True,
    loss_duplicate_reordered_after_com_write=[0, 0, 0],
    source_not_offered_total=90, source_not_offered_reconnect_frames=[100, 188],
    source_not_offered_outside_gap=[356], source_skipped_value_outside_gap='+0.056',
    reconnect_transition=dict(before_frame=99, after_frame=189, before_value='-0.201', after_value='-0.111',
                              nominal_receiver_step_s=.1, windows_write_event_gap_s=(after[0]['t_ns'] - before[-1]['t_ns']) / 1e9),
    windows_control_pause_s=(pause_end['t_ns'] - pause_start['t_ns']) / 1e9,
    windows_pids=[e['pid'] for e in started], intentional_child_exit_codes=[e['exit_code'] for e in exited],
    controller_completed=True,
    windows_before_event_counts=dict(collections.Counter(e['outcome'] for e in before_events)),
    windows_after_event_counts=dict(collections.Counter(e['outcome'] for e in after_events)),
    nominal_export_span_s=(rows[-1][0] - rows[0][0]).total_seconds(),
    windows_write_event_span_s=(writes[-1]['t_ns'] - writes[0]['t_ns']) / 1e9,
    tdms_channel_properties=c.properties,
    receiver_display_recovered_without_manual_reconnect=True,
    limits=['Process restart during live synthetic publication demonstrated; no network blackout or cable/OS reboot test',
            'Latest publication selected, no intermediate history replay; no measured capture age or physical latency',
            'Receiver nominal time grid removes interruption and omitted values, real DUT release remains locked',
            'Frame356 never offered by latest selection, not lost after COM submission; exact scheduling cause not isolated'],
    reader=dict(package='npTDMS', version='1.13.0', loading='isolated wheel, no installation', numpy_path=np.__file__),
    files_sha256={str(p.relative_to(run)): hashlib.sha256(p.read_bytes()).hexdigest()
                  for folder in ('receiver', 'windows', 'pi-publisher') for p in sorted((run / folder).iterdir()) if p.is_file()},
    recipe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
)
(run / 'recording-comparison.json').write_text(json.dumps(report, indent=2, default=str) + '\n')
setup_path = run / 'setup.json'
setup = json.loads(setup_path.read_text())
setup.update(state='synthetic_bridge_process_restart_recording_fully_compared', receiver_recording_received=True,
             windows_controller_logs_received=True, receiver_comparison='recording-comparison.json',
             receiver_all_510_written_values_exact=True, controller_completed=True)
setup_path.write_text(json.dumps(setup, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ('files_sha256', 'recipe_sha256', 'reader')}, indent=2, default=str))
