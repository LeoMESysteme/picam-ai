﻿& {
    $ErrorActionPreference = 'Stop'
    $gsvApp = 'C:\Users\EE-User-4\gsvmulti-demo-da3ed32a\bridge'
    $gsvRun = Join-Path $gsvApp ('tcp-demo-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $gsvRun | Out-Null
    $gsvLog = Join-Path $gsvRun 'bridge.jsonl'
    "Logdatei: $gsvLog"
    'Bruecke wartet auf den Pi-Sender; bis dahin sind Verbindungswarnungen erwartet.'
    & "$gsvApp\.venv\Scripts\python.exe" "$gsvApp\gsv-bridge.py" --tcp-host 100.122.154.35 --tcp-port 5000 --com-port COM5 --rate-hz 100 --log $gsvLog
    "Bruecken-Exitcode: $LASTEXITCODE"
}
