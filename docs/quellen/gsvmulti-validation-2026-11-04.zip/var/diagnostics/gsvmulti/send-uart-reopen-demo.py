"""Local experiment recipe; uses the project's existing synthetic demo sender."""
from pathlib import Path
from dataclasses import asdict
from datetime import UTC, datetime
import argparse
import hashlib
import json
import time
import serial
from dispread.records import ValueRecord, ValueStatus, Timestamp, InvalidValuePolicy
from dispread.records import TimeBaseKind
from dispread.sink.protocol.user_defined import UserDefinedFormatter


# Throwaway valid-only COM-close/reopen fixture, no product code change.
REOPEN_BLOCKS = [("before_close", 100, 1, 300),
                 ("close_window", -100, -1, 300),
                 ("reopen_fresh_window", 600, 1, 300)]

def send_reopen_demo(com, *, count=900, rate_hz=10, log=None, phase_log=None,
                     completion_stage="pi_uart_driver_write", wait=time.sleep,
                     announce=print):
    assert count == sum(n for _, _, _, n in REOPEN_BLOCKS) == 900 and rate_hz == 10
    formatter = UserDefinedFormatter()
    index = 0
    def phase(name):
        event = dict(phase=name, t_ns=time.monotonic_ns(), time_base="host_monotonic",
                     next_frame_sequence=index, demo=True, provisional=True)
        if phase_log is not None:
            phase_log.write(json.dumps(event) + "\n")
            phase_log.flush()
        announce("PHASE: " + name, flush=True)
    for name, milli_start, milli_step, length in REOPEN_BLOCKS:
        phase(name)
        for offset in range(length):
            raw = f"{(milli_start + milli_step*offset)/1000:+08.3f}"
            record = ValueRecord(index, Timestamp(index, TimeBaseKind.SYNTHETIC),
                float(raw), "mV/V", ValueStatus.VALID, 1.0,
                "demo/uart-reopen-fixture", None, None, raw_text=raw)
            payload = formatter.format(record)
            if com.write(payload) != len(payload):
                raise RuntimeError("partial UART reopen-fixture write")
            if log is not None:
                log.write(json.dumps(dict(demo=True, provisional=True,
                    format_id=formatter.capabilities.format_id,
                    capture_time_base="synthetic", frame_sequence=index,
                    stimulus_phase=name, value_status=record.status.value,
                    wire_bytes_hex=payload.hex(), completion_stage=completion_stage,
                    t_ns=time.monotonic_ns(), time_base="host_monotonic"), allow_nan=False) + "\n")
                log.flush()
            index += 1
            wait(1 / rate_hz)
    phase("sender_sequence_finished")

parser = argparse.ArgumentParser()
parser.add_argument('--count', type=int, default=900)
args = parser.parse_args()
base = Path('var/diagnostics/gsvmulti')
for number in range(1, 1000):
    run = base / f'uart-direct-demo-20261104-{number:02d}'
    try:
        run.mkdir(parents=True, exist_ok=False)
        break
    except FileExistsError:
        continue
else:
    raise RuntimeError('No unused run directory')
caps = asdict(UserDefinedFormatter().capabilities)
caps['supported_invalid_policies'] = sorted(caps['supported_invalid_policies'])
meta = dict(schema='gsv-uart-demo/v1', demo=True, provisional=True,
    transport='uart_direct', port='/dev/ttyAMA0', receiver_port_reported='COM4',
    baudrate=115200, bytesize=8, parity='N', stopbits=1, handshake=False,
    source_time_base=TimeBaseKind.SYNTHETIC.value,
    transmit_time_base=TimeBaseKind.HOST_MONOTONIC.value,
    count_requested=args.count, target_rate_hz=10, formatter_capabilities=caps,
    state='starting', sent_driver_records=0, receiver_evidence=None,
    fixture_blocks=[dict(phase=name,milli_start=start,milli_step=step,count=n) for name,start,step,n in REOPEN_BLOCKS],
    receiver_replace_missing_values_instructed=True,
    invalid_policy='omit_record', invalid_scope='all records valid synthetic demo; no real DUT output release',
    started_at_utc=datetime.now(UTC).isoformat(),
    procedure='COM close/reopen probe: 300 unique +0.100..+0.399, 300 unique -0.100..-0.399 while user closes receiver COM, then 300 unique +0.600..+0.899 while user reopens. No pause or resend at Pi, target 10Hz throughout. User instructed stop recording/measurement before Device Close, then Device Open/Start Measuring/Start Recording after fresh-window signal. Receiver action boundaries not independently timestamped. Same physical UART, no native GSV command or real DUT release',
    receipt_scope='Pi UART driver accepted bytes; not proof of GSVmulti reception',
    time_claim='Host sender runtime only; no sensor latency or synchronization claim')
paths = [Path(__file__), Path('src/dispread/gsv_bridge.py'),
         Path('src/dispread/sink/protocol/user_defined.py'), Path('src/dispread/records.py')]
meta['source_sha256'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
path = run / 'session.json'
def save():
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(meta, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)
save()
print(f'RUN_DIR={run.resolve()}', flush=True)
started = time.monotonic_ns()
meta['t_sender_start_ns'] = started
try:
    with (run / 'tx.jsonl').open('x', encoding='utf-8') as log, (run / 'phase-events.jsonl').open('x', encoding='utf-8') as phase_log:
        with serial.Serial('/dev/ttyAMA0', baudrate=115200, bytesize=8,
                           parity=serial.PARITY_NONE, stopbits=1, timeout=.1,
                           write_timeout=1, xonxoff=False, rtscts=False,
                           dsrdtr=False, exclusive=True) as port:
            meta['state'] = 'sending'
            save()
            print(f'SENDER RUNNING: {args.count} synthetic records, target 10 Hz.', flush=True)
            send_reopen_demo(port, count=args.count, rate_hz=10, log=log, phase_log=phase_log,
                      completion_stage='pi_uart_driver_write')
    meta['state'] = 'sender_completed'
except BaseException as exc:
    meta['state'] = 'sender_failed'
    meta['error'] = f'{type(exc).__name__}: {exc}'
    raise
finally:
    meta['t_sender_end_ns'] = time.monotonic_ns()
    meta['sender_runtime_s'] = (meta['t_sender_end_ns'] - started) / 1e9
    meta['ended_at_utc'] = datetime.now(UTC).isoformat()
    log_path = run / 'tx.jsonl'
    if log_path.exists():
        events = [json.loads(line) for line in log_path.read_text().splitlines() if line.strip()]
        meta['sent_driver_records'] = len(events)
        meta['bytes_driver_accepted'] = sum(len(bytes.fromhex(e['wire_bytes_hex'])) for e in events)
        meta['first_wire_bytes_hex'] = events[0]['wire_bytes_hex'] if events else None
        meta['last_wire_bytes_hex'] = events[-1]['wire_bytes_hex'] if events else None
        meta['tx_log_sha256'] = hashlib.sha256(log_path.read_bytes()).hexdigest()
    save()
    print(json.dumps(meta, indent=2), flush=True)
