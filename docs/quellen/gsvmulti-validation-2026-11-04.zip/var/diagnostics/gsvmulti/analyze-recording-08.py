"""Compare no-byte outage fixture, phase marks, and the user's recording."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime
import itertools,json,hashlib,shutil,sys
root=Path(__file__).resolve().parent;run=root/'uart-direct-demo-20261104-08'
attachment=Path('/home/me-systeme/.codex/attachments/44719ea3-b765-40b1-a46a-753ad9404261')
receiver=run/'receiver';receiver.mkdir(exist_ok=True)
files=list(attachment.glob('04_11_26-13_37_00.*'));assert len(files)==3
for p in files:shutil.copy2(p,receiver/p.name)
shot=Path('/home/me-systeme/.codex/attachments/4577e924-7fe2-4945-9777-13165c196a6f/codex-clipboard-4ae48456-bcc3-4997-b43b-081b3af61ce7.png')
shutil.copy2(shot,receiver/'receiver-timeout.png')
wheel=next((root/'analysis-tools').glob('nptdms-1.13.0-*.whl'));sys.path.insert(0,str(wheel))
from nptdms import TdmsFile
import numpy as np
rows=[]
for line in (receiver/'04_11_26-13_37_00.txt').read_text(encoding='utf-8-sig').splitlines():
 if line.startswith('04.11.2026 '):
  t,v=line.split('\t');rows.append((datetime.strptime(t.replace(',','.'),'%d.%m.%Y %H:%M:%S.%f'),Decimal(v.replace(',','.'))))
values=[v for _,v in rows]
tx=[json.loads(l) for l in (run/'tx.jsonl').read_text().splitlines()]
sent=[Decimal(bytes.fromhex(e['wire_bytes_hex']).decode().strip()[1:]) for e in tx]
phases=[json.loads(l) for l in (run/'phase-events.jsonl').read_text().splitlines()]
by_phase={p['phase']:p for p in phases}
f=TdmsFile.read(receiver/'04_11_26-13_37_00.tdms');assert len(f.groups())==1
g=f.groups()[0];assert len(g.channels())==1;c=g.channels()[0]
blocks=lambda seq:[{'value_decimal':str(v),'count':len(list(items))} for v,items in itertools.groupby(seq)]
float_expected=np.asarray([float(v) for v in sent],dtype=np.float64)
text_deltas=[(b[0]-a[0]).total_seconds() for a,b in zip(rows,rows[1:])]
transition=next(i for i in range(1,len(values)) if values[i]!=values[i-1])
paused_from=by_phase['pause_started_no_bytes_for_30s']['t_ns'];paused_until=by_phase['pause_ended']['t_ns']
report={
 'schema':'gsv-uart-outage-comparison/v1','demo':True,'provisional':True,
 'uploaded_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
 'screenshot_sha256':hashlib.sha256(shot.read_bytes()).hexdigest(),
 'recipe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'tx_log_sha256':hashlib.sha256((run/'tx.jsonl').read_bytes()).hexdigest(),
 'phase_log_sha256':hashlib.sha256((run/'phase-events.jsonl').read_bytes()).hexdigest(),
 'reader':{'package':'npTDMS','version':'1.13.0','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'numpy_path':np.__file__,'loading':'isolated wheel import; no project environment install'},
 'sender_count':len(sent),'text_count':len(values),'tdms_count':len(c),
 'text_exact_entire_sender_sequence':values==sent,
 'tdms_exact_float64_sender_sequence':bool(np.array_equal(c[:],float_expected)),
 'tdms_exact_float64_text_values':bool(np.array_equal(c[:],np.asarray([float(v) for v in values]))),
 'sender_blocks':blocks(sent),'recorded_blocks':blocks(values),
 'pause_host_monotonic_s':(paused_until-paused_from)/1e9,
 'sender_events_during_pause':sum(paused_from<=e['t_ns']<paused_until for e in tx),
 'boundary_sender_last_before_index':299,'boundary_sender_first_after_index':300,
 'boundary_sender_gap_host_monotonic_s':(tx[300]['t_ns']-tx[299]['t_ns'])/1e9,
 'boundary_recorded_transition_index':transition,
 'boundary_recorded_gap_s':(rows[transition][0]-rows[transition-1][0]).total_seconds(),
 'text_step_min_s':min(text_deltas),'text_step_max_s':max(text_deltas),
 'text_first_time':rows[0][0].isoformat(),'text_last_time':rows[-1][0].isoformat(),
 'text_nominal_span_s':(rows[-1][0]-rows[0][0]).total_seconds(),
 'sender_first_to_last_event_span_s':(tx[-1]['t_ns']-tx[0]['t_ns'])/1e9,
 'tdms_channel_properties':c.properties,'tdms_group_properties':g.properties,
 'timeout_evidence':{'source':'user screenshot supplied for pause','measurement_field':'timeout!','status':'Recording started','screenshot_time_alignment':'not independently timestamped; no timeout-delay measurement'},
 'recovery_evidence':{'source':'user explicit reply plus recorded new-value block','user_reply':'Ohne manuellen Eingriff','manual_action_reported':False,'scope':'automatic continuation after no-byte pause with same physical UART; not reconnect after cable or process loss'},
 'pause_representation':'No separate rows, time gap or invalid flag for intentional no-byte pause in uploaded text; fixed nominal grid compresses the gap',
 'time_scope':{'source':'synthetic','sender_events':'host_monotonic','receiver_axis':'nominal 10-Hz waveform with host-wall-clock origin; not source/receipt event timestamps','uncertainty_ns':None},
 'limits':['Constant values cannot expose compensating losses/repetitions','No measured timeout delay or pre-timeout stale-value display interval','No NaN, actual DUT invalidation, cable loss, process restart or common Windows bridge test','No latency/synchronization claim','Uploaded absolute start time is not a verified alignment with first sender event']}
(run/'recording-comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str,allow_nan=False)+'\n')
meta_path=run/'session.json';m=json.loads(meta_path.read_text());m['receiver_evidence']={'kind':'uploaded_tdms_text_timeout_screenshot_and_user_reply','comparison':'recording-comparison.json','count':len(values),'exact_entire_numeric_sequence':values==sent,'timeout_visible':True,'automatic_continuation_reported':True,'pause_missing_from_nominal_time_axis':report['boundary_recorded_gap_s']==.1,'scope':'No-byte pause is not preserved as invalid interval in nominal waveform; real DUT gate remains locked'};meta_path.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('uploaded_sha256','screenshot_sha256','recipe_sha256','reader','tx_log_sha256','phase_log_sha256','tdms_group_properties')},indent=2,default=str))
assert report['text_exact_entire_sender_sequence']
assert report['tdms_exact_float64_sender_sequence']
assert report['tdms_exact_float64_text_values']
assert report['sender_events_during_pause']==0
assert report['boundary_recorded_gap_s']==0.1
assert report['text_count']==500 and transition==300
