"""Audit independent synthetic publication and reconnect selection on the Pi."""
from pathlib import Path
from decimal import Decimal
import collections
import hashlib
import json

root = Path(__file__).resolve().parent
run = root / 'tcp-reconnect-20261104-01'
pub = run / 'pi-publisher'

def read(name):
    return [json.loads(s) for s in (pub / name).read_text().splitlines() if s.strip()]

meta = json.loads((pub / 'session.json').read_text())
records = read('records.jsonl')
events = read('output.jsonl')
source_events = read('source-events.jsonl')
starts = [e for e in source_events if e['event'] == 'publish_start']
completed = [e for e in source_events if e['event'] == 'publish_complete']
connections = [e for e in events if e['event'] == 'connected']
disconnections = [e for e in events if e['event'] == 'disconnected']
offers = [e for e in events if e['event'] == 'offered']
acks = [e for e in events if e['event'] == 'ack']
unconfirmed = [e for e in events if e['event'] == 'unconfirmed']
run_id = meta['output']['run_id']
seq = list(range(600))
assert meta['published'] == meta['count_requested'] == 600
assert meta['end_reason'] == 'completed' and meta['final_frame_ack_written'] is True
assert meta['output_status']['state'] == 'stopped' and meta['output_status']['error'] is None
assert meta['demo'] is meta['provisional'] is meta['source_progress_independent_of_ack'] is True
assert meta['time_claim'] is False
assert [e['frame_sequence'] for e in records] == [e['frame_sequence'] for e in starts] == [e['frame_sequence'] for e in completed] == seq
assert all(e['status'] == 'valid' and e['unit'] == 'mV/V' and e['capture_timestamp']['base'] == 'synthetic' for e in records)
assert [Decimal(e['raw_text']) for e in records] == [Decimal(i - 300) / 1000 for i in seq]
assert all(e['run_id'] == run_id and e['time_base'] == 'host_monotonic' for e in events)
assert all(e['time_base'] == 'host_monotonic' for e in source_events)
assert len(connections) == 2 and len(disconnections) == 1
assert connections[0]['t_ns'] < disconnections[0]['t_ns'] < connections[1]['t_ns']
assert all(a['outcome'] == 'written' for a in acks)
offer_by_request = {e['request_id']: e for e in offers}
assert len(offer_by_request) == len(offers)
for ack in acks:
    offer = offer_by_request[ack['request_id']]
    assert ack['frame_sequence'] == offer['frame_sequence'] and ack['barrier_id'] == offer['barrier_id']
    assert offer['t_ns'] <= ack['t_ns']
for offer in offers:
    latest_complete = max((e['frame_sequence'] for e in completed if e['t_ns'] <= offer['t_ns']), default=-1)
    latest_start = max((e['frame_sequence'] for e in starts if e['t_ns'] <= offer['t_ns']), default=-1)
    assert latest_complete <= offer['frame_sequence'] <= latest_start
offer_seq = [e['frame_sequence'] for e in offers]
assert all(a < b for a, b in zip(offer_seq, offer_seq[1:]))
assert acks[-1]['frame_sequence'] == 599
before = [e for e in offers if e['t_ns'] < disconnections[0]['t_ns']]
after = [e for e in offers if e['t_ns'] >= connections[1]['t_ns']]
assert before and after and after[0]['frame_sequence'] > before[-1]['frame_sequence'] + 1
during_gap = [e for e in completed if disconnections[0]['t_ns'] < e['t_ns'] < connections[1]['t_ns']]
assert len(during_gap) > 0
assert set(offer_by_request) == {e['request_id'] for e in acks} | {e['request_id'] for e in unconfirmed}
missing_offers = sorted(set(seq) - set(offer_seq))
missing_at_reconnect = list(range(before[-1]['frame_sequence'] + 1, after[0]['frame_sequence']))
missing_outside_reconnect = sorted(set(missing_offers) - set(missing_at_reconnect))
report = dict(
    schema='gsv-tcp-reconnect-source-audit/v1', all_comparison_assertions_passed=True,
    demo=True, provisional=True, time_claim=False, run_id=run_id,
    source_count=len(records), source_publish_start_count=len(starts), source_publish_complete_count=len(completed),
    process_exit_code=0, process_exit_evidence='exec session93547 returned exit_code0',
    source_progress_independent_of_ack=True, source_event_counts=dict(collections.Counter(e['event'] for e in events)),
    offered_count=len(offers), written_ack_count=len(acks), unconfirmed_count=len(unconfirmed),
    connections=connections, disconnections=disconnections,
    before_last_offered_frame=before[-1]['frame_sequence'], after_first_offered_frame=after[0]['frame_sequence'],
    before_offered_count=len(before), after_offered_count=len(after),
    published_between_disconnect_and_reconnect=len(during_gap),
    disconnect_to_reconnect_s=(connections[1]['t_ns'] - disconnections[0]['t_ns']) / 1e9,
    source_publish_event_span_s=(completed[-1]['t_ns'] - completed[0]['t_ns']) / 1e9,
    not_offered_count=len(missing_offers), not_offered_sequences=missing_offers,
    skipped_between_before_and_after_count=len(missing_at_reconnect),
    not_offered_outside_reconnect_gap=missing_outside_reconnect,
    first_after_matches_latest_publication_bounds=True, all_offers_match_latest_publication_bounds=True,
    no_historical_backlog_offered=True, final_ack_written=True,
    source_status_stopped=True, source_error=None,
    receiver_display_recovered_without_manual_reconnect=True,
    receiver_display_evidence='user: Ja, wechselnde Zahlen ohne Eingriff',
    receiver_recording_checked=False, windows_controller_logs_received=False,
    time_scope='All event differences on Pi HOST_MONOTONIC only; SYNTHETIC capture, no physical age or latency',
    limits=['ACK is COM driver write only, receiver files pending',
            'No measured frame age: only publication sequence/latest selection demonstrated',
            'No receiver invalid-time preservation proof, real DUT output remains locked'],
    files_sha256={name: hashlib.sha256((pub / name).read_bytes()).hexdigest() for name in ('session.json', 'records.jsonl', 'source-events.jsonl', 'output.jsonl')},
    recipe_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
)
(run / 'source-audit-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
setup_path = run / 'setup.json'
setup = json.loads(setup_path.read_text())
setup.update(state='source_completed, awaiting Windows controller archive and GSVmulti recording',
             source_started=True, source_completed=True, source_run_id=run_id,
             source_process_exit_code=0,
             source_comparison='source-audit-comparison.json', receiver_recording_received=False,
             windows_controller_logs_received=False)
setup_path.write_text(json.dumps(setup, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ('files_sha256', 'recipe_sha256', 'not_offered_sequences')}, indent=2))
