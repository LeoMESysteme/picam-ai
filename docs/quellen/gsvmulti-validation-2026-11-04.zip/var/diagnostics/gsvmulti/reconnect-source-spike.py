"""Throwaway synthetic source advancing independently of COM acknowledgements."""
import argparse
import json
import time
from pathlib import Path

from dispread.gsv_bridge import demo_records
from dispread.gsv_transport import OutputConfig, OutputPublisher
from dispread.sink.jsonl import JsonlSink


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', default='100.122.154.35')
    parser.add_argument('--port', type=int, default=5000)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--count', type=int, default=600)
    parser.add_argument('--rate-hz', type=float, default=10)
    parser.add_argument('--connect-timeout', type=float, default=300)
    args = parser.parse_args()
    if not (2 <= args.count <= 100000 and 0 < args.rate_hz <= 100 and 0 < args.connect_timeout <= 300):
        parser.error('Invalid diagnostic bounds')
    args.out_dir.mkdir(parents=True, exist_ok=False)
    pub = OutputPublisher(OutputConfig(transport='tcp', tcp_host=args.host, tcp_port=args.port), args.out_dir, demo=True)
    audit = JsonlSink(args.out_dir / 'records.jsonl', max_bytes=0)
    meta = dict(demo=True, provisional=True, time_claim=False, throwaway_diagnostic=True,
                source_progress_independent_of_ack=True, output=pub.metadata(),
                count_requested=args.count, rate_target_hz=args.rate_hz, published=0,
                end_reason='starting', final_frame_ack_written=False)

    def save():
        (args.out_dir / 'session.json').write_text(json.dumps(meta, indent=2) + '\n')

    result = 1
    try:
        save()
        audit.open()
        with (args.out_dir / 'source-events.jsonl').open('x') as source_log:
            def event(kind, **details):
                source_log.write(json.dumps(dict(event=kind, t_ns=time.monotonic_ns(),
                                                time_base='host_monotonic', demo=True,
                                                provisional=True, **details)) + '\n')
                source_log.flush()

            pub.start()
            deadline = time.monotonic() + args.connect_timeout
            while pub.status()['state'] != 'bridge_connected':
                if time.monotonic() >= deadline:
                    raise TimeoutError('No bridge connected')
                time.sleep(.02)
            meta['end_reason'] = 'running'
            save()
            event('source_started')
            for record in demo_records(args.count):
                emitted = time.monotonic()
                receipt = audit.emit(record)
                if receipt.t_complete_ns is None or audit.health().errors:
                    raise OSError('Source audit failed')
                event('publish_start', frame_sequence=record.frame_sequence)
                pub.publish(record)
                event('publish_complete', frame_sequence=record.frame_sequence, output_status=pub.status())
                meta['published'] += 1
                # No wait for an ACK, including while the bridge is disconnected.
                time.sleep(max(0, 1 / args.rate_hz - (time.monotonic() - emitted)))
            event('source_generation_finished', published=meta['published'])
            deadline = time.monotonic() + 10
            while time.monotonic() < deadline:
                ack = pub.status()['last_ack']
                if ack and ack['frame_sequence'] == args.count - 1 and ack['outcome'] == 'written':
                    meta['final_frame_ack_written'] = True
                    break
                time.sleep(.02)
            meta['end_reason'] = 'completed' if meta['final_frame_ack_written'] else 'source_complete_final_ack_missing'
            event('drain_finished', final_frame_ack_written=meta['final_frame_ack_written'])
            result = 0 if meta['final_frame_ack_written'] else 2
    except KeyboardInterrupt:
        meta['end_reason'] = 'interrupted'
        result = 130
    except Exception as exc:
        meta['end_reason'] = f'{type(exc).__name__}: {exc}'
    finally:
        try:
            pub.stop()
        finally:
            audit.close()
            meta['output_status'] = pub.status()
            save()
    print(json.dumps(meta, indent=2))
    return result


if __name__ == '__main__':
    raise SystemExit(main())
