"""Compare the received Windows-local demo recording with its original TX log."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime
import sys,json,hashlib,shutil
root=Path(__file__).resolve().parent
run=root/'windows-local-demo-20261104-01'
receiver=run/'receiver';receiver.mkdir(exist_ok=True)
attachments=Path('/home/me-systeme/.codex/attachments/8e036fba-94e9-4f40-af0e-1e7ef59a47ac')
files=list(attachments.glob('04_11_26-17_12_38.*'))
assert len(files)==3
for f in files:
 dst=receiver/f.name
 if dst.exists():assert dst.read_bytes()==f.read_bytes()
 else:shutil.copy2(f,dst)
src=Path('/home/me-systeme/.codex/attachments/e3c6c882-182d-437b-921f-b3d3552743cc/bridge.jsonl')
dst=run/'bridge.jsonl'
if dst.exists():assert dst.read_bytes()==src.read_bytes()
else:shutil.copy2(src,dst)
events=[json.loads(l) for l in dst.read_text(encoding='utf-8-sig').splitlines() if l.strip()]
wire=[bytes.fromhex(e['wire_bytes_hex']) for e in events]
assert all(x.startswith(b'%') and x.endswith(b'\r\n') for x in wire)
sent=[Decimal(x[1:-2].decode('ascii')) for x in wire]
expected=[Decimal(i-300)/1000 for i in range(600)]
rows=[]
for line in (receiver/'04_11_26-17_12_38.txt').read_text(encoding='utf-8-sig').splitlines():
 if line.startswith('04.11.2026 '):
  t,v=line.split('\t');rows.append((datetime.strptime(t.replace(',','.'),'%d.%m.%Y %H:%M:%S.%f'),Decimal(v.replace(',','.'))))
values=[v for _,v in rows]
wheel=next((root/'analysis-tools').glob('nptdms-1.13.0-*.whl'));sys.path.insert(0,str(wheel))
from nptdms import TdmsFile
import numpy as np
f=TdmsFile.read(receiver/'04_11_26-17_12_38.tdms');assert len(f.groups())==1
g=f.groups()[0];assert len(g.channels())==1
c=g.channels()[0];data=c[:]
starts=[i for i in range(len(sent)-len(values)+1) if sent[i:i+len(values)]==values]
steps=np.diff(np.array([e['t_ns'] for e in events],dtype=np.int64))/1e9
span=(events[-1]['t_ns']-events[0]['t_ns'])/1e9
text_steps=[(b[0]-a[0]).total_seconds() for a,b in zip(rows,rows[1:])]
report={'schema':'gsv-windows-local-demo-comparison/v1','demo':True,'provisional':True,
 'files_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [*files,src]},
 'recipe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'reader':{'package':'npTDMS','version':'1.13.0','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'numpy_path':np.__file__,'loading':'isolated wheel import; no environment installation'},
 'sender_count':len(events),'sender_requested_count':600,'sender_bytes_in_log':sum(map(len,wire)),
 'sender_frame_sequence_exact_0_to_599':[e['frame_sequence'] for e in events]==list(range(600)),
 'sender_values_exact_fixture':sent==expected,'sender_all_flags_and_scopes_valid':all(e['demo'] is True and e['provisional'] is True and e['capture_time_base']=='synthetic' and e['time_base']=='host_monotonic' and e['completion_stage']=='com_driver_write' and e['format_id']=='user_defined/provisional' for e in events),
 'sender_event_span_s':span,'sender_event_time_base':'host_monotonic on Windows, not capture time',
 'sender_event_intervals_positive':bool((steps>0).all()),'sender_interval_min_s':float(steps.min()),'sender_interval_max_s':float(steps.max()),'sender_interval_median_s':float(np.median(steps)),
 'sender_average_inter_record_rate_hz':(len(events)-1)/span,'sender_target_rate_hz':10,
 'text_count':len(values),'tdms_count':len(data),'text_matches_all_sender_values':values==sent,'matching_sender_start_indices':starts,
 'text_first_value':str(values[0]),'text_last_value':str(values[-1]),
 'text_duplicate_value_count':len(values)-len(set(values)),'text_unique_step_values':sorted({str((b-a).normalize()) for a,b in zip(values,values[1:])}),
 'tdms_equals_text_float64':bool(np.array_equal(data,np.asarray([float(v) for v in values]))),
 'tdms_equals_sender_float64':bool(np.array_equal(data,np.asarray([float(v) for v in sent]))),
 'tdms_nan_count':int(np.isnan(data).sum()),'tdms_infinite_count':int(np.isinf(data).sum()),
 'text_step_min_s':min(text_steps),'text_step_max_s':max(text_steps),'nominal_export_span_s':(rows[-1][0]-rows[0][0]).total_seconds(),
 'text_first_wall_time_unmapped':rows[0][0].isoformat(),'text_last_wall_time_unmapped':rows[-1][0].isoformat(),
 'tdms_group_properties':g.properties,'tdms_channel_properties':c.properties,
 'time_scope':{'source_records':'synthetic, no capture latency information','sender_write_event_intervals':'Windows host_monotonic','receiver_axis':'nominal waveform, origin from external wall-clock text, not mapped capture or reception times','uncertainty_ns':None},
 'limits':['Local demo mode bypasses Pi/TCP/UART JSONL and ACK exchange','No invalid/stale interval, disconnect or buffer-age acceptance','No latency or cross-clock claim','Sender process exit code not supplied, all600 send records are supplied','Observed average Windows demo rate is below10Hz target; cause not isolated','Not a real DUT run; output gate remains locked']}
report['nominal_span_minus_sender_event_span_s']=report['nominal_export_span_s']-span
(run/'recording-comparison.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,default=str,allow_nan=False)+'\n')
meta=run/'setup.json';m=json.loads(meta.read_text());m.update({'demo_started':True,'gsvmulti_profile_prepared':True,'receiver_recording_received':True,'receiver_comparison':'recording-comparison.json','sender_exit_code_reported':None});meta.write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('files_sha256','reader','recipe_sha256','tdms_group_properties')},indent=2,default=str))
assert report['sender_count']==600
assert report['sender_frame_sequence_exact_0_to_599'] and report['sender_values_exact_fixture'] and report['sender_all_flags_and_scopes_valid']
assert report['text_matches_all_sender_values'] and report['tdms_equals_sender_float64'] and report['tdms_equals_text_float64']
assert report['text_count']==report['tdms_count']==600
assert c.properties['unit_string']=='mV/V'
assert c.properties['Frequency']==10.0 and c.properties['Scaling']==1.0
assert c.properties['DevComNo']==6
assert report['text_unique_step_values']==['0.001']
