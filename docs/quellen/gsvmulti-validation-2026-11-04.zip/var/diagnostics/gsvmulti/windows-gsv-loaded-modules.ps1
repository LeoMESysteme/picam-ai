﻿& {
    Get-Process -Name 'GSVmulti*' -Module -FileVersionInfo |
        Where-Object { [System.IO.Path]::GetFileName($_.FileName) -match 'gsv' } |
        Select-Object FileName, FileVersion, ProductVersion |
        Format-List
}
