"""Local experiment recipe; uses the project's existing synthetic demo sender."""
from pathlib import Path
from dataclasses import asdict
from datetime import UTC, datetime
import argparse
import hashlib
import json
import time
import serial
from dispread.records import ValueRecord, ValueStatus, Timestamp
from dispread.records import TimeBaseKind
from dispread.sink.protocol.user_defined import UserDefinedFormatter


# Throwaway omission/outage fixture; no invalid numbers or replacement values sent.
def send_outage_demo(com, *, count=500, rate_hz=10, log=None, phase_log=None,
                     completion_stage="pi_uart_driver_write", wait=time.sleep,
                     announce=print):
    assert count == 500 and rate_hz == 10
    formatter = UserDefinedFormatter()
    index = 0
    def phase(name):
        event = dict(phase=name, t_ns=time.monotonic_ns(), time_base="host_monotonic",
                     next_frame_sequence=index, demo=True, provisional=True)
        if phase_log is not None:
            phase_log.write(json.dumps(event) + "\n")
            phase_log.flush()
        announce("PHASE: " + name, flush=True)
    for name, raw, length in [("sending_before_pause", "+000.250", 300),
                               ("sending_after_pause", "-000.750", 200)]:
        if index == 300:
            phase("pause_started_no_bytes_for_30s")
            wait(30)
            phase("pause_ended")
        phase(name)
        for _ in range(length):
            record = ValueRecord(index, Timestamp(index, TimeBaseKind.SYNTHETIC),
                                 float(raw), "mV/V", ValueStatus.VALID, 1.0,
                                 "demo/uart-outage-fixture", None, None, raw_text=raw)
            payload = formatter.format(record)
            if com.write(payload) != len(payload):
                raise RuntimeError("partial UART outage-fixture write")
            if log is not None:
                log.write(json.dumps(dict(demo=True, provisional=True,
                    format_id=formatter.capabilities.format_id,
                    capture_time_base="synthetic", frame_sequence=index,
                    wire_bytes_hex=payload.hex(), completion_stage=completion_stage,
                    t_ns=time.monotonic_ns(), time_base="host_monotonic")) + "\n")
                log.flush()
            index += 1
            wait(1 / rate_hz)
    phase("sender_sequence_finished")

parser = argparse.ArgumentParser()
parser.add_argument('--count', type=int, default=500)
args = parser.parse_args()
base = Path('var/diagnostics/gsvmulti')
for number in range(1, 1000):
    run = base / f'uart-direct-demo-20261104-{number:02d}'
    try:
        run.mkdir(parents=True, exist_ok=False)
        break
    except FileExistsError:
        continue
else:
    raise RuntimeError('No unused run directory')
caps = asdict(UserDefinedFormatter().capabilities)
caps['supported_invalid_policies'] = sorted(caps['supported_invalid_policies'])
meta = dict(schema='gsv-uart-demo/v1', demo=True, provisional=True,
    transport='uart_direct', port='/dev/ttyAMA0', receiver_port_reported='COM4',
    baudrate=115200, bytesize=8, parity='N', stopbits=1, handshake=False,
    source_time_base=TimeBaseKind.SYNTHETIC.value,
    transmit_time_base=TimeBaseKind.HOST_MONOTONIC.value,
    count_requested=args.count, target_rate_hz=10, formatter_capabilities=caps,
    state='starting', sent_driver_records=0, receiver_evidence=None,
    fixture_blocks=[dict(raw_text='+000.250',count=300),dict(pause_s=30,no_bytes=True),dict(raw_text='-000.750',count=200)],
    started_at_utc=datetime.now(UTC).isoformat(),
    procedure='Outage fixture: 300 values +0.250, 30 s intentional no-byte pause with UART port kept open, 200 fresh values -0.750. Target 10 Hz when sending; no NaN, invalid or old values replayed. GSVmulti is instructed to keep measuring/recording; observe timeout, modal messages, export and recovery without manual reconnect. Recording boundary not independently logged; nominal grid is not valid across the pause.',
    receipt_scope='Pi UART driver accepted bytes; not proof of GSVmulti reception',
    time_claim='Host sender runtime only; no sensor latency or synchronization claim')
paths = [Path(__file__), Path('src/dispread/gsv_bridge.py'),
         Path('src/dispread/sink/protocol/user_defined.py'), Path('src/dispread/records.py')]
meta['source_sha256'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
path = run / 'session.json'
def save():
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(meta, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)
save()
print(f'RUN_DIR={run.resolve()}', flush=True)
started = time.monotonic_ns()
meta['t_sender_start_ns'] = started
try:
    with (run / 'tx.jsonl').open('x', encoding='utf-8') as log, (run / 'phase-events.jsonl').open('x', encoding='utf-8') as phase_log:
        with serial.Serial('/dev/ttyAMA0', baudrate=115200, bytesize=8,
                           parity=serial.PARITY_NONE, stopbits=1, timeout=.1,
                           write_timeout=1, xonxoff=False, rtscts=False,
                           dsrdtr=False, exclusive=True) as port:
            meta['state'] = 'sending'
            save()
            print(f'SENDER RUNNING: {args.count} synthetic records, target 10 Hz.', flush=True)
            send_outage_demo(port, count=args.count, rate_hz=10, log=log, phase_log=phase_log,
                      completion_stage='pi_uart_driver_write')
    meta['state'] = 'sender_completed'
except BaseException as exc:
    meta['state'] = 'sender_failed'
    meta['error'] = f'{type(exc).__name__}: {exc}'
    raise
finally:
    meta['t_sender_end_ns'] = time.monotonic_ns()
    meta['sender_runtime_s'] = (meta['t_sender_end_ns'] - started) / 1e9
    meta['ended_at_utc'] = datetime.now(UTC).isoformat()
    log_path = run / 'tx.jsonl'
    if log_path.exists():
        events = [json.loads(line) for line in log_path.read_text().splitlines() if line.strip()]
        meta['sent_driver_records'] = len(events)
        meta['bytes_driver_accepted'] = sum(len(bytes.fromhex(e['wire_bytes_hex'])) for e in events)
        meta['first_wire_bytes_hex'] = events[0]['wire_bytes_hex'] if events else None
        meta['last_wire_bytes_hex'] = events[-1]['wire_bytes_hex'] if events else None
        meta['tx_log_sha256'] = hashlib.sha256(log_path.read_bytes()).hexdigest()
    save()
    print(json.dumps(meta, indent=2), flush=True)
