"""Throwaway Windows controller: terminate only its own bridge, then restart."""
import argparse
import json
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bridge-dir', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    app = args.bridge_dir.resolve()
    python = app / '.venv' / 'Scripts' / 'python.exe'
    bridge = app / 'gsv-bridge.py'
    if not python.is_file() or not bridge.is_file():
        parser.error('Windows bridge folder or .venv missing')
    run = app / ('tcp-reconnect-' + uuid.uuid4().hex)
    run.mkdir(exist_ok=False)
    shutil.copy2(__file__, run / 'controller-copy.py')
    child = None
    handles = []
    report = dict(demo=True, provisional=True, time_claim=False, throwaway_diagnostic=True,
                  bridge_dir=str(app), pi_host='100.122.154.35', pi_port=5000,
                  com_port='COM5', stop_after_written_count=100, pause_s=10,
                  final_frame_sequence=599, completed=False)
    print('Diagnoseordner: ' + str(run), flush=True)
    with (run / 'control.jsonl').open('x', encoding='utf-8') as control:
        def event(kind, **details):
            control.write(json.dumps(dict(event=kind, t_ns=time.monotonic_ns(),
                                         time_base='host_monotonic', demo=True,
                                         provisional=True, **details)) + '\n')
            control.flush()

        def start(phase):
            log = run / (phase + '.jsonl')
            out = (run / (phase + '-stdout.txt')).open('x', encoding='utf-8')
            err = (run / (phase + '-stderr.txt')).open('x', encoding='utf-8')
            handles.extend([out, err])
            process = subprocess.Popen([str(python), str(bridge), '--tcp-host', '100.122.154.35',
                                        '--tcp-port', '5000', '--com-port', 'COM5', '--rate-hz', '100',
                                        '--log', str(log)], cwd=app, stdout=out, stderr=err)
            event('bridge_started', phase=phase, pid=process.pid)
            return process, log

        def read_log(path):
            if not path.exists():
                return []
            events = []
            for line in path.read_text(encoding='utf-8').splitlines():
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    pass  # A concurrent final line may still be incomplete.
            return events

        def wait_for(process, path, predicate, timeout):
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise RuntimeError('Bridge exited early: ' + str(process.returncode))
                events = read_log(path)
                if any('COM open:' in e.get('error', '') for e in events):
                    raise RuntimeError('COM5 cannot open. Close the previous Windows bridge first.')
                writes = [e for e in events if e.get('outcome') == 'written']
                if predicate(writes):
                    return writes
                time.sleep(.05)
            raise TimeoutError('Diagnostic phase timed out; inspect bridge logs')

        def terminate(process, phase):
            if process.poll() is None:
                event('terminate_requested', phase=phase, pid=process.pid)
                process.terminate()  # Intentional process interruption; only our own PID.
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
            event('bridge_exited', phase=phase, pid=process.pid, exit_code=process.returncode)

        try:
            child, log = start('before')
            print('Bereit: GSVmulti-Aufnahme muss laufen. Jetzt im Chat bereit melden.', flush=True)
            before = wait_for(child, log, lambda writes: len(writes) >= 100, 360)
            event('interruption_trigger', written_count=len(before), last_frame=before[-1]['frame_sequence'])
            print('Bruecke wird fuer zehn Sekunden beendet; Pi-Quelle soll weiterlaufen.', flush=True)
            terminate(child, 'before')
            child = None
            event('pause_started')
            time.sleep(10)
            event('pause_finished')
            child, log = start('after')
            print('Bruecke neu gestartet. Warte auf letzten Demowert +0,299.', flush=True)
            after = wait_for(child, log, lambda writes: any(e['frame_sequence'] == 599 for e in writes), 120)
            event('final_frame_written', first_after_frame=after[0]['frame_sequence'],
                  last_after_frame=after[-1]['frame_sequence'], after_count=len(after))
            time.sleep(2)
            report['completed'] = True
        except KeyboardInterrupt:
            report['error'] = 'controller interrupted by user'
        except Exception as exc:
            report['error'] = f'{type(exc).__name__}: {exc}'
            print(report['error'], flush=True)
        finally:
            if child is not None:
                terminate(child, 'cleanup')
            for handle in handles:
                handle.close()
            event('controller_finished', completed=report['completed'])
            (run / 'summary.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    archive = shutil.make_archive(str(run), 'zip', root_dir=run)
    print('GSVmulti-Aufnahme jetzt stoppen und TXT/TDMS exportieren.', flush=True)
    print('Brueckenbelege: ' + archive, flush=True)
    return 0 if report['completed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
