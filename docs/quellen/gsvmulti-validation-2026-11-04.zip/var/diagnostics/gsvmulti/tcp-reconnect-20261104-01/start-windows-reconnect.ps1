﻿& {
    $ErrorActionPreference = 'Stop'
    $gsvApp = 'C:\Users\EE-User-4\gsvmulti-demo-da3ed32a\bridge'
    $gsvController = Join-Path $gsvApp 'gsvmulti-reconnect-controller-2026-11-04.py'
    scp 'me-systeme@100.122.154.35:/home/me-systeme/picam-ai/var/exports/gsvmulti-reconnect-controller-2026-11-04.py' $gsvController
    if ($LASTEXITCODE -ne 0) { throw 'SCP fehlgeschlagen' }
    $gsvExpected = '0d956e79764a8e6d7d8b0f50fd4f1f40e787fe01fc157309ffc37399526ff5f1'
    if ((Get-FileHash -LiteralPath $gsvController -Algorithm SHA256).Hash.ToLowerInvariant() -ne $gsvExpected) {
        throw 'Dateipruefsumme stimmt nicht'
    }
    & "$gsvApp\.venv\Scripts\python.exe" $gsvController --bridge-dir $gsvApp
    "Diagnose-Exitcode: $LASTEXITCODE"
}
