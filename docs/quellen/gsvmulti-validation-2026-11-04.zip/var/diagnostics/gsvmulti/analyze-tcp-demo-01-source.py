"""Validate Pi-side audit and ACK linkage for the first shared TCP demo."""
from pathlib import Path
from decimal import Decimal
import json,hashlib,collections
root=Path(__file__).resolve().parent
run=root/'tcp-demo-20261104-01';pub=run/'pi-publisher'
meta=json.loads((pub/'session.json').read_text())
records=[json.loads(l) for l in (pub/'records.jsonl').read_text().splitlines() if l.strip()]
events=[json.loads(l) for l in (pub/'output.jsonl').read_text().splitlines() if l.strip()]
offers=[e for e in events if e['event']=='offered'];acks=[e for e in events if e['event']=='ack']
seq=list(range(600));rid=meta['output']['run_id']
assert meta['demo'] is True and meta['provisional'] is True and meta['time_claim'] is False
assert meta['count_requested']==meta['completed']==600 and meta['end_reason']=='completed'
assert meta['output_status']['state']=='stopped' and meta['output_status']['error'] is None
assert [e['frame_sequence'] for e in records]==[e['frame_sequence'] for e in offers]==[e['frame_sequence'] for e in acks]==seq
assert all(e['status']=='valid' and e['unit']=='mV/V' and e['capture_timestamp']['base']=='synthetic' and e['value']==float(e['raw_text']) for e in records)
assert [Decimal(e['raw_text']) for e in records]==[Decimal(i-300)/1000 for i in seq]
assert all(e['run_id']==rid and e['time_base']=='host_monotonic' for e in events)
assert all(a['outcome']=='written' and a['request_id']==o['request_id'] and a['frame_sequence']==o['frame_sequence'] and o['t_ns']<=a['t_ns'] for o,a in zip(offers,acks))
assert len({e['request_id'] for e in offers})==600
ackspan=(acks[-1]['t_ns']-acks[0]['t_ns'])/1e9
report={'schema':'gsv-tcp-source-audit/v1','demo':True,'provisional':True,'process_exit_code':0,'process_exit_evidence':'exec session81398 completed with exit_code0','run_id':rid,'source_audited_records':len(records),'offered_records':len(offers),'acks_received':len(acks),'all_acks_written':True,'all_frame_sequences_exact_0_to_599':True,'all_request_run_frame_links_valid':True,'source_event_counts':dict(collections.Counter(e['event'] for e in events)),'source_values_first_last':[records[0]['raw_text'],records[-1]['raw_text']],'ack_event_span_s':ackspan,'mean_ack_event_rate_hz':599/ackspan,'ack_event_time_base':'host_monotonic on Pi, not Windows clock and not synthetic capture time','offer_event_span_s':(offers[-1]['t_ns']-offers[0]['t_ns'])/1e9,'source_stopped':True,'source_error':None,'receiver_display_confirmed':True,'receiver_display_evidence':'user: Ja, wechselnde Zahlen werden angezeigt','receiver_recording_checked':False,'windows_bridge_log_received':False,'limits':['ACKs prove Windows COM-driver submission only, not GSVmulti recording','Capture timestamps are synthetic; no DUT latency or physical timing claim','Pi and Windows monotonic clocks are distinct and unmapped','No invalid/stale/reconnect acceptance or real DUT output'],'files_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in (pub/'session.json',pub/'records.jsonl',pub/'output.jsonl')},'recipe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(run/'source-audit-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
setup=run/'setup.json';s=json.loads(setup.read_text());s.update({'state':'source_completed, waiting receiver evidence','source_started':True,'source_completed':True,'source_process_exit_code':0,'run_id':rid,'source_audit':'source-audit-comparison.json','receiver_recording_received':False,'windows_bridge_log_received':False});setup.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('files_sha256','recipe_sha256')},indent=2))
