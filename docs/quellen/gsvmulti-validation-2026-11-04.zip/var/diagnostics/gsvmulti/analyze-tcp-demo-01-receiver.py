"""Compare the first shared TCP recording with Pi audit and both ACK logs."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime
import collections
import hashlib
import json
import shutil
import sys

root = Path(__file__).resolve().parent
run = root / 'tcp-demo-20261104-01'
receiver = run / 'receiver'
receiver.mkdir(exist_ok=True)
attachment_dir = Path('/home/me-systeme/.codex/attachments/3767f2b9-d86b-41e1-9efa-ccecf1a738c3')
files = sorted(attachment_dir.glob('04_11_26-17_24_44.*'))
assert {p.suffix for p in files} == {'.txt', '.tdms', '.tdms_index'}
bridge_attachment = Path('/home/me-systeme/.codex/attachments/b959971b-4b13-4fb1-b93e-36302d8957f0/bridge.jsonl')
for src, dst in [(p, receiver / p.name) for p in files] + [(bridge_attachment, run / 'bridge.jsonl')]:
    if dst.exists():
        assert dst.read_bytes() == src.read_bytes(), f'Existing original differs: {dst}'
    else:
        shutil.copy2(src, dst)

def read_jsonl(path):
    return [json.loads(s) for s in path.read_text(encoding='utf-8-sig').splitlines() if s.strip()]

pub = run / 'pi-publisher'
meta = json.loads((pub / 'session.json').read_text())
records = read_jsonl(pub / 'records.jsonl')
source_events = read_jsonl(pub / 'output.jsonl')
offers = [e for e in source_events if e['event'] == 'offered']
source_acks = [e for e in source_events if e['event'] == 'ack']
bridge_events = read_jsonl(run / 'bridge.jsonl')
writes = [e for e in bridge_events if e['outcome'] == 'written']
seq = list(range(600))
run_id = meta['output']['run_id']
expected = [Decimal(i - 300) / 1000 for i in seq]
assert meta['completed'] == meta['count_requested'] == 600
assert meta['end_reason'] == 'completed'
assert meta['demo'] is True and meta['provisional'] is True and meta['time_claim'] is False
assert len(records) == len(offers) == len(source_acks) == len(writes) == 600
assert [e['frame_sequence'] for e in records] == seq
assert [e['frame_sequence'] for e in offers] == seq
assert [e['frame_sequence'] for e in source_acks] == seq
assert [e['frame_sequence'] for e in writes] == seq
assert all(r['status'] == 'valid' and r['unit'] == 'mV/V' and r['capture_timestamp']['base'] == 'synthetic' for r in records)
source_values = [Decimal(r['raw_text']) for r in records]
assert source_values == expected
assert all(e['provisional'] is True and e['time_base'] == 'host_monotonic' for e in bridge_events)
assert all(e['format_id'] == 'user_defined/provisional' and e['carries_capture_timestamp'] is False for e in writes)
assert all(e['completion_stage'] == 'com_driver_write' for e in writes)
assert all(e['outcome'] == 'written' for e in source_acks)
assert len({e['request_id'] for e in writes}) == 600
for offer, ack, write in zip(offers, source_acks, writes):
    assert offer['run_id'] == ack['run_id'] == write['run_id'] == run_id
    assert offer['request_id'] == ack['request_id'] == write['request_id']
    assert ack['barrier_id'] == write['barrier_id']
wire = [bytes.fromhex(e['wire_bytes_hex']) for e in writes]
assert wire == [('%' + r['raw_text'] + '\r\n').encode('ascii') for r in records]
wire_values = [Decimal(b[1:-2].decode('ascii')) for b in wire]
assert wire_values == source_values

rows = []
for line in (receiver / '04_11_26-17_24_44.txt').read_text(encoding='utf-8-sig').splitlines():
    if line.startswith('04.11.2026 '):
        t, v = line.split('\t')
        rows.append((datetime.strptime(t.replace(',', '.'), '%d.%m.%Y %H:%M:%S.%f'), Decimal(v.replace(',', '.'))))
values = [v for _, v in rows]
assert values == source_values
assert len(values) == 600 and len(set(values)) == 600
assert {b - a for a, b in zip(values, values[1:])} == {Decimal('0.001')}

wheel = next((root / 'analysis-tools').glob('nptdms-1.13.0-*.whl'))
sys.path.insert(0, str(wheel))
from nptdms import TdmsFile
import numpy as np
tdms = TdmsFile.read(receiver / '04_11_26-17_24_44.tdms')
assert len(tdms.groups()) == 1
group = tdms.groups()[0]
assert len(group.channels()) == 1
channel = group.channels()[0]
data = channel[:]
assert len(data) == 600
assert np.array_equal(data, np.asarray([float(v) for v in values]))
assert np.array_equal(data, np.asarray([float(v) for v in source_values]))
assert np.isfinite(data).all()
assert channel.properties['unit_string'] == channel.properties['NI_UnitDescription'] == 'mV/V'
assert channel.properties['Frequency'] == 10.0 and channel.properties['Scaling'] == 1.0
assert channel.properties['DevComNo'] == 6
assert channel.properties['wf_increment'] == 0.1

first = bridge_events.index(writes[0])
last = bridge_events.index(writes[-1])
during = bridge_events[first:last + 1]
assert all(e['outcome'] in ('written', 'idle') for e in during)
assert sum(e['outcome'] == 'ended' for e in bridge_events) == 1
assert all(b['t_ns'] >= a['t_ns'] for a, b in zip(bridge_events, bridge_events[1:]))
intervals = np.diff(np.asarray([e['t_ns'] for e in writes], dtype=np.int64)) / 1e9
assert (intervals > 0).all()
span = (writes[-1]['t_ns'] - writes[0]['t_ns']) / 1e9
txt_steps = [(b[0] - a[0]).total_seconds() for a, b in zip(rows, rows[1:])]
assert min(txt_steps) == max(txt_steps) == 0.1
report = {
    'schema': 'gsv-tcp-receiver-comparison/v1',
    'all_comparison_assertions_passed': True,
    'demo': True, 'provisional': True, 'time_claim': False, 'run_id': run_id,
    'source_count': len(records), 'source_offer_count': len(offers), 'source_ack_count': len(source_acks),
    'windows_written_count': len(writes), 'windows_written_bytes': sum(map(len, wire)),
    'text_count': len(values), 'tdms_count': len(data),
    'all_request_run_frame_links_valid': True, 'all_sequences_exact_0_to_599': True,
    'all_wire_bytes_match_source': True, 'text_matches_source_decimal': True,
    'tdms_matches_text_and_source_float64': True,
    'first_value': str(values[0]), 'last_value': str(values[-1]), 'value_step': '0.001',
    'missing_duplicate_reordered_values': [0, 0, 0],
    'bridge_event_counts': dict(collections.Counter(e['outcome'] for e in bridge_events)),
    'bridge_events_before_first_write': dict(collections.Counter(e['outcome'] for e in bridge_events[:first])),
    'bridge_events_during_writes': dict(collections.Counter(e['outcome'] for e in during)),
    'bridge_events_after_last_write': dict(collections.Counter(e['outcome'] for e in bridge_events[last + 1:])),
    'bridge_connection_error_messages': sorted({e['error'] for e in bridge_events if e['outcome'] == 'connection_error'}),
    'windows_write_event_span_s': span, 'windows_mean_write_event_rate_hz': 599 / span,
    'windows_write_interval_min_median_max_s': [float(intervals.min()), float(np.median(intervals)), float(intervals.max())],
    'windows_write_event_time_base': 'HOST_MONOTONIC on Windows; independent of Pi clock',
    'nominal_export_span_s': (rows[-1][0] - rows[0][0]).total_seconds(),
    'text_step_min_max_s': [min(txt_steps), max(txt_steps)],
    'tdms_group_properties': group.properties, 'tdms_channel_properties': channel.properties,
    'receiver_axis_scope': 'Nominal 1/f0 grid, not measured arrival times',
    'reader': {'package': 'npTDMS', 'version': '1.13.0', 'wheel_sha256': hashlib.sha256(wheel.read_bytes()).hexdigest(), 'numpy_path': np.__file__, 'loading': 'isolated wheel import, no installation'},
    'files_sha256': {str(p.relative_to(run)): hashlib.sha256(p.read_bytes()).hexdigest() for p in [*sorted(receiver.iterdir()), run / 'bridge.jsonl', pub / 'session.json', pub / 'records.jsonl', pub / 'output.jsonl']},
    'recipe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'limits': [
        'Full valid synthetic sequence accepted over shared TCP path; no real DUT release',
        'No invalid/stale interval, disconnect-during-stream or backlog acceptance',
        'Start/end connection retries are outside numeric transfer; do not prove reconnect under load',
        'No latency or cross-clock measurement; capture timestamps synthetic, uncertainty_ns=None',
        'Windows process exit code and explicit cleanup confirmation not supplied',
    ],
}
(run / 'recording-comparison.json').write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str, allow_nan=False) + '\n')
setup_path = run / 'setup.json'
setup = json.loads(setup_path.read_text())
setup.update(state='valid_synthetic_tcp_sequence_fully_recorded_and_compared', receiver_recording_received=True,
             windows_bridge_log_received=True, receiver_comparison='recording-comparison.json',
             receiver_all_600_values_exact=True, windows_bridge_exit_code_reported=None)
setup_path.write_text(json.dumps(setup, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ('files_sha256', 'reader', 'recipe_sha256', 'tdms_group_properties')}, indent=2, default=str))
