﻿& {
    $ErrorActionPreference = 'Stop'
    $gsvApp = 'C:\Users\EE-User-4\gsvmulti-demo-da3ed32a\bridge'
    $gsvRun = Join-Path $gsvApp ('local-demo-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $gsvRun | Out-Null
    $gsvLog = Join-Path $gsvRun 'bridge.jsonl'
    'Demo startet: COM5, 600 Werte, Zielrate 10 Hz.'
    & "$gsvApp\.venv\Scripts\python.exe" "$gsvApp\gsv-bridge.py" --demo --com-port COM5 --count 600 --rate-hz 10 --log $gsvLog
    $gsvExit = $LASTEXITCODE
    "Sender-Exitcode: $gsvExit"
    "Logdatei: $gsvLog"
    if ($gsvExit -ne 0) { throw 'Demo nicht erfolgreich beendet; Log und Fehlermeldung sichern.' }
}
