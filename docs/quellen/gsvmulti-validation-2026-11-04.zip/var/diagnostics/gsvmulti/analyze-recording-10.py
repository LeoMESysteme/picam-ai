"""Analyze the demo-only NaN marker probe without assuming receiver support."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime
import itertools,json,hashlib,shutil,sys
root=Path(__file__).resolve().parent;run=root/'uart-direct-demo-20261104-10'
attachment=Path('/home/me-systeme/.codex/attachments/08fe79a5-b2c0-4861-9197-5c1314e6741c')
receiver=run/'receiver';receiver.mkdir(exist_ok=True)
files=list(attachment.glob('04_11_26-13_48_50.*'));assert len(files)==3
for p in files:shutil.copy2(p,receiver/p.name)
shot=Path('/home/me-systeme/.codex/attachments/ca23251d-43e7-4f87-ba73-e3024cd11b0d/codex-clipboard-11a87a89-0b17-4852-a69b-ce6fa8bf10eb.png')
shutil.copy2(shot,receiver/'receiver-nan-interval-timeout.png')
wheel=next((root/'analysis-tools').glob('nptdms-1.13.0-*.whl'));sys.path.insert(0,str(wheel))
from nptdms import TdmsFile
import numpy as np
rows=[]
for line in (receiver/'04_11_26-13_48_50.txt').read_text(encoding='utf-8-sig').splitlines():
 if line.startswith('04.11.2026 '):
  t,v=line.split('\t');rows.append((datetime.strptime(t.replace(',','.'),'%d.%m.%Y %H:%M:%S.%f'),Decimal(v.replace(',','.'))))
values=[v for _,v in rows]
tx=[json.loads(l) for l in (run/'tx.jsonl').read_text().splitlines()]
wire=[bytes.fromhex(e['wire_bytes_hex']) for e in tx]
valid_events=[e for e,payload in zip(tx,wire) if payload!=b'%NaN\r\n']
sent_valid=[Decimal(bytes.fromhex(e['wire_bytes_hex']).decode().strip()[1:]) for e in valid_events]
phases=[json.loads(l) for l in (run/'phase-events.jsonl').read_text().splitlines()];by_phase={p['phase']:p for p in phases}
f=TdmsFile.read(receiver/'04_11_26-13_48_50.tdms');assert len(f.groups())==1
g=f.groups()[0];assert len(g.channels())==1;c=g.channels()[0];data=c[:]
starts=[i for i in range(len(sent_valid)-len(values)+1) if sent_valid[i:i+len(values)]==values]
blocks=lambda seq:[{'value_decimal':str(v),'count':len(list(items))} for v,items in itertools.groupby(seq)]
text_deltas=[(b[0]-a[0]).total_seconds() for a,b in zip(rows,rows[1:])]
transition=next(i for i in range(1,len(values)) if values[i]!=values[i-1])
report={
 'schema':'gsv-uart-nan-probe-comparison/v1','demo':True,'provisional':True,
 'uploaded_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
 'screenshot_sha256':hashlib.sha256(shot.read_bytes()).hexdigest(),
 'recipe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'tx_log_sha256':hashlib.sha256((run/'tx.jsonl').read_bytes()).hexdigest(),
 'phase_log_sha256':hashlib.sha256((run/'phase-events.jsonl').read_bytes()).hexdigest(),
 'reader':{'package':'npTDMS','version':'1.13.0','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'numpy_path':np.__file__,'loading':'isolated wheel import, no environment installation'},
 'sender_total_count':len(tx),'sender_valid_count':len(valid_events),'sender_nan_marker_count':wire.count(b'%NaN\r\n'),
 'sender_invalid_source_status':'unreadable with value=None; synthetic demo only',
 'nan_phase_host_monotonic_s':(by_phase['valid_after_nan']['t_ns']-by_phase['nan_interval']['t_ns'])/1e9,
 'sender_gap_between_last_pre_nan_and_first_post_nan_numeric_s':(tx[500]['t_ns']-tx[299]['t_ns'])/1e9,
 'text_count':len(values),'tdms_count':len(data),
 'text_nan_count':sum(v.is_nan() for v in values),'tdms_nan_count':int(np.isnan(data).sum()),
 'tdms_infinite_count':int(np.isinf(data).sum()),'tdms_large_marker_count':int((np.abs(data)>=1e299).sum()),
 'tdms_exact_float64_text_values':bool(np.array_equal(data,np.asarray([float(v) for v in values]),equal_nan=True)),
 'matching_start_indices_in_valid_only_sender_sequence':starts,
 'recorded_blocks':blocks(values),'text_step_min_s':min(text_deltas),'text_step_max_s':max(text_deltas),
 'recorded_numeric_transition_index':transition,'recorded_gap_at_numeric_transition_s':(rows[transition][0]-rows[transition-1][0]).total_seconds(),
 'text_first_time':rows[0][0].isoformat(),'text_last_time':rows[-1][0].isoformat(),'nominal_export_span_s':(rows[-1][0]-rows[0][0]).total_seconds(),
 'tdms_channel_properties':c.properties,'tdms_group_properties':g.properties,
 'screenshot_evidence':'timeout! in Measuring Value; Recording started',
 'user_observation':'während NaN wieder timeout udn recorder grafik bleibt auch wieder stehen',
 'receiver_replace_missing_values_confirmed':True,
 'receiver_option_confirmation':'User checked after test and replied: Ja, der Haken ist gesetzt',
 'interpretation':'Replace Missing Values confirmed on, yet no missing-value markers retained. Uploaded values match a suffix of valid-only sender sequence; no NaN/large invalid marker rows in TDMS/text; NaN interval missing from nominal waveform. Receiver-side cause not isolated; numeric filter remained enabled.',
 'time_scope':{'source':'synthetic','sender_events':'host_monotonic','receiver_axis':'nominal 10-Hz waveform, host-wall-clock origin; not verified event times','uncertainty_ns':None},
 'limits':['Numeric filter enabled; cannot generalize to all UserDefined configurations or native GSV protocols','No timed receiver-side byte capture or timeout delay measurement','Manual recording boundary not independently logged','No real DUT or common Windows bridge acceptance','Negative result bounded to this UserDefined profile; no universal claim about other devices']}
if len(starts)==1:
 i=starts[0];matched=valid_events[i:i+len(values)]
 report.update(omitted_valid_prefix_count=i,matched_first_sender_frame_sequence=matched[0]['frame_sequence'],matched_last_sender_frame_sequence=matched[-1]['frame_sequence'],sender_matched_numeric_event_span_s=(matched[-1]['t_ns']-matched[0]['t_ns'])/1e9)
(run/'recording-comparison.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,default=str,allow_nan=False)+'\n')
meta_path=run/'session.json';m=json.loads(meta_path.read_text());m['receiver_evidence']={'kind':'uploaded_tdms_text_timeout_screenshot_and_user_observation','comparison':'recording-comparison.json','count':len(values),'nan_count':report['tdms_nan_count'],'timeout_visible':True,'receiver_replace_missing_values_confirmed':True,'scope':'No NaN or missing-value marker retained with confirmed Replace Missing Values; invalid interval compressed; no real DUT release'};meta_path.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('uploaded_sha256','screenshot_sha256','recipe_sha256','reader','tx_log_sha256','phase_log_sha256','tdms_group_properties')},indent=2,default=str))
assert report['sender_nan_marker_count']==200
assert report['tdms_exact_float64_text_values']
assert len(starts)==1
