"""Read-only comparison recipe for the uploaded UART recording, not runtime code."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime
import hashlib,json,shutil,sys,statistics
root=Path(__file__).resolve().parent
run=root/'uart-direct-demo-20261104-06'
attachment=Path('/home/me-systeme/.codex/attachments/3b0cf42a-a982-4510-b9e5-485cee595663')
receiver=run/'receiver';receiver.mkdir(exist_ok=True)
files=list(attachment.glob('04_11_26-13_27_12.*'))
for p in files:shutil.copy2(p,receiver/p.name)
wheel=next((root/'analysis-tools').glob('nptdms-1.13.0-*.whl'))
sys.path.insert(0,str(wheel))
from nptdms import TdmsFile
import numpy as np
lines=(receiver/'04_11_26-13_27_12.txt').read_text(encoding='utf-8-sig').splitlines()
rows=[]
for line in lines:
 if line.startswith('04.11.2026 '):
  ts,value=line.split('\t')
  rows.append((datetime.strptime(ts.replace(',','.'),'%d.%m.%Y %H:%M:%S.%f'),Decimal(value.replace(',','.'))))
assert rows
export_values=[v for _,v in rows]
tx=[json.loads(l) for l in (run/'tx.jsonl').read_text().splitlines()]
sent_values=[Decimal(bytes.fromhex(r['wire_bytes_hex']).decode().strip()[1:]) for r in tx]
first=sent_values.index(export_values[0]);last=sent_values.index(export_values[-1])
expected=sent_values[first:last+1]
f=TdmsFile.read(receiver/'04_11_26-13_27_12.tdms')
g=f.groups()[0];assert len(f.groups())==1 and len(g.channels())==1
c=g.channels()[0]
float_expected=np.asarray([float(v) for v in expected],dtype=np.float64)
report={
 'schema':'gsv-uart-recording-comparison/v1','demo':True,'provisional':True,
 'uploaded_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
 'recipe_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'tx_log_sha256':hashlib.sha256((run/'tx.jsonl').read_bytes()).hexdigest(),
 'reader':{'package':'npTDMS','version':'1.13.0','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'loading':'sys.path from wheel; no environment installation; no dependencies downloaded','numpy_path':np.__file__},
 'sender_count':len(tx),'text_count':len(rows),'tdms_count':len(c),
 'first_value_decimal':str(export_values[0]),'last_value_decimal':str(export_values[-1]),
 'matched_sender_first_index_zero_based':first,'matched_sender_last_index_zero_based':last,
 'text_exact_contiguous_sender_subsequence':export_values==expected,
 'tdms_exact_float64_sender_subsequence':bool(np.array_equal(c[:],float_expected)),
 'tdms_exact_float64_text_values':bool(np.array_equal(c[:],np.asarray([float(v) for v in export_values]))),
 'max_tdms_abs_difference_from_sender_float64':float(np.max(np.abs(c[:]-float_expected))),
 'internal_gap_or_step_error_count':sum(b-a!=Decimal('.001') for a,b in zip(export_values,export_values[1:])),
 'duplicate_value_count':len(export_values)-len(set(export_values)),
 'negative_count':sum(v<0 for v in export_values),'zero_count':sum(v==0 for v in export_values),'positive_count':sum(v>0 for v in export_values),
 'omitted_prefix_count':first,'omitted_suffix_count':len(tx)-1-last,
 'omission_scope':'Prefix before first recorded value; later manual start consistent but precise start boundary not independently logged. No whole-run losslessness claim.',
 'source_time_base':'synthetic','sender_event_time_base':'host_monotonic',
 'receiver_time_base':'GSVmulti generated waveform time, host wall-clock origin; alignment/accuracy unknown',
 'receiver_text_time_basis':'local display per TDMS ToffsetUTC=1.0; no uncertainty estimate',
 'text_first_time':rows[0][0].isoformat(),'text_last_time':rows[-1][0].isoformat(),
 'text_time_span_s':(rows[-1][0]-rows[0][0]).total_seconds(),
 'text_step_min_s':min((b[0]-a[0]).total_seconds() for a,b in zip(rows,rows[1:])),
 'text_step_max_s':max((b[0]-a[0]).total_seconds() for a,b in zip(rows,rows[1:])),
 'tdms_waveform_increment_s':float(c.properties['wf_increment']),
 'tdms_waveform_implied_rate_hz':1/float(c.properties['wf_increment']),
 'sender_matched_event_span_s':(tx[last]['t_ns']-tx[first]['t_ns'])/1e9,
 'header_frequency_hz':float(c.properties['Frequency']),
 'tdms_group_properties':g.properties,'tdms_channel_properties':c.properties,
 'limits':['No abrupt jumps or invalid records tested','No timestamp or latency verification','No common Windows bridge acceptance','No real DUT output release'],
}
assert report['text_exact_contiguous_sender_subsequence']
assert report['tdms_exact_float64_sender_subsequence']
assert report['tdms_exact_float64_text_values']
(run/'recording-comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str,allow_nan=False)+'\n')
meta_path=run/'session.json';meta=json.loads(meta_path.read_text())
meta['receiver_evidence']={'kind':'uploaded_tdms_and_text','comparison':'recording-comparison.json','count':len(rows),'first_sender_index_zero_based':first,'last_sender_index_zero_based':last,'exact_contiguous_sender_subsequence':True,'scope':f'{len(rows)} recorded values unchanged, internal sequence contiguous; full 600 reception not established; time axis unverified'}
meta_path.write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('uploaded_sha256','tdms_channel_properties','tdms_group_properties','reader','recipe_sha256','tx_log_sha256')},indent=2))
