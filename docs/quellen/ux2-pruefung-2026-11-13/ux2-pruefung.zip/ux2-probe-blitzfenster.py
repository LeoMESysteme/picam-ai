"""Findet Widgets, die kurz als eigenes Fenster (Top-Level) gezeigt werden, und nennt die Stelle im Code."""
import os
import sys
import traceback
from collections import Counter

os.environ.setdefault('DISPREAD_UI_FIRST_RUN_MODES', '0')
from PySide6.QtCore import QEvent, QObject
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QMainWindow, QMenu, QToolTip  # noqa: F401

app = QApplication(sys.argv[:1])
from dispread_bridge_app.ui.fake import FakeController  # noqa: E402
from dispread_bridge_app.ui.window import MainWindow  # noqa: E402
from dispread_bridge_app.ui import tool_windows  # noqa: E402

EXPECTED = (QMainWindow, tool_windows.ToolWindow) if hasattr(tool_windows, 'ToolWindow') else (QMainWindow,)
hits = Counter()
where = {}


class Spy(QObject):
    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Type.Show and getattr(obj, 'isWindow', None) and obj.isWindow():
            name = type(obj).__name__
            if not isinstance(obj, EXPECTED) and name not in ('QTipLabel', 'QMenu', 'QComboBoxPrivateContainer'):
                frames = [f for f in traceback.extract_stack()[:-1] if 'dispread_bridge_app' in f.filename]
                key = (name, f'{os.path.basename(frames[-1].filename)}:{frames[-1].lineno}' if frames else '?')
                hits[key] += 1
                where.setdefault(key, ' <- '.join(f'{os.path.basename(f.filename)}:{f.lineno}' for f in frames[-4:][::-1]))
        return False


spy = Spy()
app.installEventFilter(spy)
for state, act in [('B1', None), ('B10', 'open_settings'), ('B1', 'open_settings'), ('B1', 'details'),
                   ('B1', 'open_modes'), ('B1', 'export_diagnostics'), ('E3', None), ('E4session', None)]:
    w = MainWindow(FakeController(state), dark=None, first_run_modes=False)
    w.resize(440, 720); w.show(); w.refresh(); QTest.qWait(300)
    if act:
        w.do_action(act); QTest.qWait(500)
    print(f'{state:10} {act or "-":20} bisher {sum(hits.values())} kurze Top-Level-Fenster')
    w.force_close(); w.deleteLater(); app.processEvents()

for (name, at), n in hits.most_common():
    print(f'{n:3}x {name:28} gezeigt in {at}   Aufrufkette: {where[(name, at)]}')
