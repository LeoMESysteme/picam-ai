"""Offline replay of the archived cell-7 setup precheck failure; no camera access."""
import argparse
import hashlib
import json
import sys
import tarfile
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', type=Path, help='Compare a different source checkout.')
parser.add_argument('--case', default=root.name, help='Session folder beside this archived case.')
args = parser.parse_args()
manifest = json.loads((root / 'MANIFEST.json').read_text())
expected = {item['path'] for item in manifest['files']}
actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name != 'MANIFEST.json'}
assert expected == actual, 'Missing or unexpected archive files'
for item in manifest['files']:
    data = (root / item['path']).read_bytes()
    assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
with tempfile.TemporaryDirectory(prefix='dispread-precheck-replay-') as temporary:
    if args.source:
        source = args.source.resolve()
    else:
        with tarfile.open(root / 'source-08ac9b9.tar.gz', 'r:gz') as archive:
            archive.extractall(temporary, filter='data')
        source = Path(temporary) / 'source'
    sys.path.insert(0, str(source / 'src'))
    import cv2
    from dispread.dotlattice import fit_lattice
    from dispread.setup_checks import check_setup
    from dispread.setup_hint import find_green_hint_box
    cv2.setNumThreads(2)
    case = root.parent / args.case
    image = cv2.imread(str(case / 'setup/still.png'))
    assert image is not None
    hint = find_green_hint_box(image)
    print(json.dumps({'starting': 'fit_lattice', 'session_id': args.case, 'hint_box': hint, 'hardware_access': False}), flush=True)
    fit = fit_lattice(image, hint, empty_cells=(8, 13, 14, 15))
    if isinstance(fit, str):
        print(json.dumps({'fit': fit, 'baseline_matches': False}), flush=True)
        raise SystemExit(0 if args.source else 2)
    checks = check_setup(image, fit).to_dict()
    edge = checks['checks']['kanten']
    matches = edge['status'] == 'FEHLER' and edge.get('cells') == [7]
    print(json.dumps({'fit': 'ok', 'quad': fit.quad, 'checks': checks,
                      'baseline_matches': matches, 'time_claim': False}, ensure_ascii=False), flush=True)
    raise SystemExit(0 if args.source or matches else 2)
