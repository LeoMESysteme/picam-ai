"""Replay one archived setup using files only; no camera, serial, or network access."""
import argparse
import hashlib
import json
import sys
import tarfile
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--verify-only', action='store_true')
parser.add_argument('--source', type=Path, help='Compare a different checkout instead of archived code.')
args = parser.parse_args()
manifest = json.loads((root / 'MANIFEST.json').read_text())
expected = {item['path'] for item in manifest['files']}
actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p != root / 'MANIFEST.json'}
assert expected == actual, 'Missing or unexpected files'
for item in manifest['files']:
    data = (root / item['path']).read_bytes()
    assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
print(json.dumps({'verified_files': len(expected), 'hardware_access': False}), flush=True)
if args.verify_only:
    raise SystemExit(0)
with tempfile.TemporaryDirectory(prefix='dispread-new-position-replay-') as temporary:
    if args.source:
        source = args.source.resolve()
    else:
        with tarfile.open(root / 'source-08ac9b9.tar.gz', 'r:gz') as archive:
            archive.extractall(temporary, filter='data')
        source = Path(temporary) / 'source'
    sys.path.insert(0, str(source / 'src'))
    import cv2
    from dispread.dotlattice import fit_lattice
    from dispread.setup_hint import find_green_hint_box
    cv2.setNumThreads(2)
    image = cv2.imread(str(root / 'setup/still.png'))
    assert image is not None
    hint = find_green_hint_box(image)
    print(json.dumps({'starting': 'fit_lattice', 'hint_box': hint}), flush=True)
    fit = fit_lattice(image, hint, empty_cells=(8, 13, 14, 15))
    observed = fit if isinstance(fit, str) else 'ok'
    result = {'session_id': 'live-20261111T162902Z', 'observed': observed,
              'expected_baseline': 'keine_startlage', 'baseline_matches': observed == 'keine_startlage',
              'time_claim': False}
    if observed == 'ok':
        result['fit'] = {'quad': fit.quad, 'n_dots': fit.n_dots, 'n_assigned': fit.n_assigned,
                         'rms_cols': fit.rms_cols, 'rms_rows': fit.rms_rows}
    print(json.dumps(result, ensure_ascii=False), flush=True)
    raise SystemExit(0 if args.source or result['baseline_matches'] else 2)
