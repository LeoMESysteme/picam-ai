"""Offline replay of the archived setup failure; never accesses a camera."""
import argparse,hashlib,json,sys,tarfile,tempfile
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',type=Path)
p.add_argument('--verify-only',action='store_true')
a=p.parse_args()
if (root/'MANIFEST.json').exists():
 for f in json.loads((root/'MANIFEST.json').read_text())['files']:
  data=(root/f['path']).read_bytes()
  assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256'],f['path']
if a.verify_only:
 print(json.dumps({'integrity':'passed','camera_access':False}));raise SystemExit(0)
with tempfile.TemporaryDirectory(prefix='dispread-focus-replay-') as tmp:
 if a.source: source=a.source.resolve()
 else:
  with tarfile.open(root/'source-08ac9b9.tar.gz') as archive: archive.extractall(tmp,filter='data')
  source=Path(tmp)/'source'
 sys.path.insert(0,str(source/'src'))
 import cv2
 from dispread.dotlattice import fit_lattice
 from dispread.setup_hint import find_green_hint_box
 from dispread.setup_checks import check_setup
 cv2.setNumThreads(2)
 image=cv2.imread(str(root/'setup/still.png'));assert image is not None
 hint=find_green_hint_box(image)
 fit=fit_lattice(image,hint,empty_cells=(8,13,14,15))
 if isinstance(fit,str):
  print(json.dumps({'fit':fit,'baseline_matches':False}));raise SystemExit(0 if a.source else 2)
 checks=check_setup(image,fit).to_dict();edge=checks['checks']['kanten']
 baseline=edge['status']=='FEHLER' and edge.get('cells')==[14,15]
 print(json.dumps({'fit':'ok','hint_box':hint,'quad':fit.quad,'checks':checks,'baseline_matches':baseline,'camera_access':False,'latency_claim':False}),flush=True)
 if not a.source: assert baseline
