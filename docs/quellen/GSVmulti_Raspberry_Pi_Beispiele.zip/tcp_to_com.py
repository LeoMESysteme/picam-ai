#!/usr/bin/env python3
"""One-way raw TCP to serial bridge. Requires an installed virtual COM PAIR.

GSVmulti opens COM20, this bridge opens its paired endpoint COM21.
Do NOT open the GSVmulti endpoint from this script.
Example: python tcp_to_com.py --host 192.168.1.50 --port 5000 --serial COM21
Only complete CRLF frames with prefix % and three numeric fields are forwarded.
After each TCP connect, discard data through the first CRLF to resynchronize.
The first (possibly complete) record is deliberately discarded.
No RFC2217, TLS, handshake, GSV command emulation or historical replay.
"""
import argparse
import math
import socket
import sys
import time


def valid_frame(line):
    if not line.startswith(b"%"):
        return False
    try:
        fields = line[1:].decode("ascii").split(";")
        return len(fields) == 3 and all(math.isfinite(float(v)) for v in fields)
    except (ValueError, UnicodeDecodeError):
        return False


def relay(conn, device):
    buffer = bytearray()
    synchronized = False
    while True:
        chunk = conn.recv(4096)
        if not chunk:
            raise ConnectionError("TCP closed")
        buffer.extend(chunk)
        while b"\r\n" in buffer:
            line, _, tail = buffer.partition(b"\r\n")
            buffer[:] = tail
            if not synchronized:
                synchronized = True
                continue
            if valid_frame(line):
                data = bytes(line) + b"\r\n"
                if device.write(data) != len(data):
                    raise IOError("Incomplete COM write")
            else:
                print("Discarded invalid frame", file=sys.stderr)
        if len(buffer) > 4096:
            raise ValueError("Frame too long or missing CRLF")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--serial", required=True)
    parser.add_argument("--baud", type=int, default=115200)
    args = parser.parse_args()
    import serial
    try:
        with serial.Serial(args.serial, args.baud, bytesize=8, parity="N", stopbits=1,
                           timeout=1, write_timeout=2, xonxoff=False,
                           rtscts=False, dsrdtr=False) as device:
            while True:
                try:
                    with socket.create_connection((args.host, args.port), timeout=5) as conn:
                        conn.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                        conn.settimeout(5)
                        print("TCP connected", file=sys.stderr)
                        relay(conn, device)
                except (OSError, ValueError) as exc:
                    print(f"TCP interrupted: {exc}; retry in 2 s", file=sys.stderr)
                    time.sleep(2)
    except KeyboardInterrupt:
        return 0
    except (OSError, ValueError) as exc:
        print(f"COM failed: {exc}; restart bridge after fixing port", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
