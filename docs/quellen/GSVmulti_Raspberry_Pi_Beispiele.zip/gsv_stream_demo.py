#!/usr/bin/env python3
"""Demonstration sender for GSVmulti PRO UserDefined. Not a sensor driver.

Serial: python3 gsv_stream_demo.py --serial /dev/serial0 --baud 115200
TCP:    python3 gsv_stream_demo.py --listen 0.0.0.0 --port 5000
stdout: python3 gsv_stream_demo.py --stdout --count 3
Wire:   %+00012.345;+00023.456;-00000.250\r\n
Replace read_values() with acquisition of three calibrated sensor values.
"""
import argparse
import math
import socket
import sys
import time


def make_frame(values):
    if len(values) != 3:
        raise ValueError("Exactly three channels required")
    fields = []
    for value in values:
        value = float(value)
        if not math.isfinite(value) or abs(value) > 99999.999:
            raise ValueError("Invalid or out-of-range sensor value")
        field = f"{value:+010.3f}"
        if len(field) != 10:
            raise ValueError("Value exceeds configured frame width")
        fields.append(field)
    return ("%" + ";".join(fields) + "\r\n").encode("ascii")


def read_values(t):
    """DEMO values only. Preserve order, units and sampling coherence in a driver."""
    return (12.345 + math.sin(t), 23.456, -0.250)


def stream(write, hz, count):
    start = time.monotonic()
    deadline = start
    sent = 0
    while not count or sent < count:
        now = time.monotonic()
        frame = make_frame(read_values(now - start))
        result = write(frame)
        if result is not None and result != len(frame):
            raise IOError("Incomplete frame write")
        sent += 1
        deadline += 1.0 / hz
        # Do not send a burst of historical samples after a scheduler pause.
        now = time.monotonic()
        if deadline < now:
            deadline = now
        time.sleep(max(0.0, deadline - now))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--serial", help="UART, USB serial or ttyGS0 device")
    mode.add_argument("--listen", help="TCP bind IP, e.g. 0.0.0.0 or 127.0.0.1")
    mode.add_argument("--stdout", action="store_true")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--hz", type=float, default=10.0)
    parser.add_argument("--count", type=int, default=0, help="0 = continuous")
    args = parser.parse_args()
    if not math.isfinite(args.hz) or args.hz <= 0 or args.count < 0:
        parser.error("hz must be finite and positive; count must be nonnegative")
    if not 1 <= args.port <= 65535:
        parser.error("port must be between 1 and 65535")
    print("DEMO DATA ONLY - replace read_values() for real sensors", file=sys.stderr)
    try:
        if args.serial:
            import serial
            with serial.serial_for_url(
                args.serial, baudrate=args.baud, bytesize=8,
                parity="N", stopbits=1, timeout=1, write_timeout=2,
                xonxoff=False, rtscts=False, dsrdtr=False,
            ) as device:
                stream(device.write, args.hz, args.count)
        elif args.stdout:
            def output(data):
                n = sys.stdout.buffer.write(data)
                sys.stdout.buffer.flush()
                return n
            stream(output, args.hz, args.count)
        else:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
                server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                server.bind((args.listen, args.port))
                server.listen(1)
                print(f"Raw TCP listening on {args.listen}:{args.port}", file=sys.stderr)
                while True:
                    conn, peer = server.accept()
                    print(f"Connected: {peer}", file=sys.stderr)
                    with conn:
                        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                        conn.settimeout(3.0)
                        try:
                            stream(conn.sendall, args.hz, args.count)
                        except (ConnectionError, TimeoutError, OSError) as exc:
                            print(f"Disconnected: {exc}", file=sys.stderr)
                    if args.count:
                        break
    except KeyboardInterrupt:
        return 0
    except (OSError, ValueError) as exc:
        print(f"Stopped: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
