GSVmulti PRO und Raspberry Pi - Beispiele, Stand 28.10.2026

Alle Werte des Senders sind DEMODATEN. Es wird kein echter Sensor ausgelesen.
Die Programme sind kein GSV-Geraeteemulator. Sie erzeugen Messwerttext fuer
Device Type UserDefined in GSVmulti PRO.

GSVmulti Value String / DEFINE
  Frame Prefix Mode: Has Character Prefix
  Define Prefix Character: %
  Number of values in String/Frame: 3
  Value Separator: Semicolon ;
  Filter-Out Non-Numeric: aus
  Add Channel: tatsaechlichen COM-Port waehlen, 115200 Bit/s,
  Open all input channels oder First=1, Last=3.
  Frame: %+00012.345;+00023.456;-00000.250<CR><LF>
  Default: 10 Frames/s, drei Werte pro Frame, 35 Bytes pro Frame.

Raspberry Pi Installation
  sudo apt update
  sudo apt install python3-serial

UART oder USB-Seriell
  python3 gsv_stream_demo.py --serial /dev/serial0 --baud 115200 --hz 10
  Auf Pi 5 den zu GPIO14/15 gehoerenden UART explizit bestimmen!
  /dev/serial0 kann dort auf den DEBUG-UART /dev/ttyAMA10 zeigen.
  Alternative: Sender an einem Pi-USB-UART, z.B. /dev/ttyUSB0.

USB-ACM-Gadget nach erfolgter Hardware- und Betriebssystemkonfiguration
  python3 gsv_stream_demo.py --serial /dev/ttyGS0 --hz 10

TCP-Server auf dem Pi im vertrauten LAN
  python3 gsv_stream_demo.py --listen 0.0.0.0 --port 5000 --hz 10
  0.0.0.0 bindet alle IPv4-Schnittstellen. Fuer SSH-Tunnel 127.0.0.1 nehmen.
  Windows-VSPE: Connector COM20 + TcpClient zum Pi:5000, Source COM20.
  Raw TCP, kein Control-Port, kein RFC2217, keine Texttransformation.
  Dann in GSVmulti COM20 oeffnen.

Alternative mit virtuellem Portpaar COM20 <-> COM21 auf Windows
  Treiber fuer das Portpaar separat installieren und konfigurieren.
  py -m pip install -r requirements.txt
  py tcp_to_com.py --host 192.168.1.50 --port 5000 --serial COM21
  GSVmulti oeffnet COM20. COM20/21 muessen frei sein; Namen sind Beispiele.
  Diese Bridge kann statt des VSPE-TcpClient eingesetzt werden.
  Sie braucht ein PAAR, nicht zwei beliebige unabhaengige COM-Ports.
  Sie verwirft nach TCP-Verbindung den ersten Datensatz zur Synchronisation.

Port pruefen, wenn GSVmulti ihn geschlossen hat
  py -m serial.tools.list_ports -v
  py -m serial.tools.miniterm COM20 115200
  Im Terminal muessen vollstaendige Zeilen erscheinen. Danach Terminal schliessen!

Echten Sensor anbinden
  read_values(t) im Sender ersetzen. Drei endliche Zahlen zurueckgeben,
  in fester Reihenfolge, in dokumentierten Einheiten. Kalibrierung und
  Sensorbus-Treiber gehoeren in diese Funktion bzw. in eine eigene Messschicht.
  Messfehler im Beispiel stoppen den Sender; nicht stillschweigend 0 senden.
  Fuer die reale Anwendung Fehlerstrategie und Zeitbasis separat festlegen.

Sicherheit und Grenzen
  Raw TCP ist unverschluesselt und ohne Authentifizierung.
  Fuer externe Verbindungen VPN oder SSH-Tunnel verwenden.
  Serialbetrieb beendet sich bei COM-Ausfall; Neustart muss verwaltet werden.
  TCP-Modus bedient einen Empfaenger. Keine historische Wiederholung.
  Kein Hardware- oder GSVmulti-Empfangstest wurde mit diesen Dateien bestaetigt.
  Einzelheiten, Quellen und Abnahmeschritte stehen in der PDF-Dokumentation.
