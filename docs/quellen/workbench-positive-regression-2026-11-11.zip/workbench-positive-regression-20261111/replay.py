"""Check successful reference setups and audit records using archived code and files."""
import argparse
from collections import Counter
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', type=Path)
p.add_argument('--verify-only', action='store_true')
p.add_argument('--historical-controls', action='store_true')
args = p.parse_args()
if (root / 'MANIFEST.json').exists():
    items = json.loads((root / 'MANIFEST.json').read_text())['files']
    for item in items:
        data = (root / item['path']).read_bytes()
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
if args.verify_only:
    print(json.dumps({'integrity': 'passed', 'hardware_access': False}))
    raise SystemExit(0)
records_path = root / 'cases/live-20261111T164508Z/run-01/records.jsonl'
records = [json.loads(line) for line in records_path.read_text().splitlines() if line.strip()]
counts = Counter(r['status'] for r in records)
session = json.loads((records_path.parent / 'session.json').read_text())
assert counts == session['summary']['by_status']
assert len(records) == 3843 and counts['valid'] == 2920
share = counts['valid'] / len(records)
assert share >= .75
assert session['summary']['tracking_lost'] == 0
assert session['summary']['audit_errors'] == 0
assert session['summary']['end_reason'] == 'bediener'
assert session['camera']['read_error'] is None
seconds = (datetime.fromisoformat(session['ended_at_utc']) - datetime.fromisoformat(session['started_at_utc'])).total_seconds()
print(json.dumps({'operation': 'audit_counts', 'records': len(records), 'counts': dict(counts),
                  'valid_share': share, 'minimum_75_percent_met_on_processed_records': share >= .75,
                  'run_wall_clock_seconds': seconds, 'duration_time_base': 'host_wall_clock_utc',
                  'duration_uncertainty_ns': None, 'frame_latency_claim': False,
                  'transport': 'uart_direct', 'windows_receiver_proof': False}), flush=True)
with tempfile.TemporaryDirectory(prefix='dispread-positive-replay-') as tmp:
    if args.source:
        source = args.source.resolve()
    else:
        with tarfile.open(root / 'source-08ac9b9.tar.gz', 'r:gz') as archive:
            archive.extractall(tmp, filter='data')
        source = Path(tmp) / 'source'
    sys.path.insert(0, str(source / 'src'))
    import cv2
    import numpy as np
    from dispread.dotlattice import evaluate_quad, fit_lattice
    from dispread.setup_hint import find_green_hint_box
    from dispread.setup_checks import check_setup, diagnose_reader, raster_offset_check
    from dispread.live.setup import DEFAULT_TARGET_SIZE, LATTICE_GRID, heldout_improves
    from dispread.lattice_offsets import refine_quad
    from dispread.live.frame_tracking import FrameTrackingConfig, _axes, _proposal_spread_limits, _reserve_ok
    cv2.setNumThreads(2)
    for folder in sorted((root / 'cases').iterdir()):
        proposal = json.loads((folder / 'setup/proposal.json').read_text())
        image = cv2.imread(str(folder / 'setup/still.png'))
        hint = find_green_hint_box(image)
        result = fit_lattice(image, hint, empty_cells=(8, 13, 14, 15))
        assert not isinstance(result, str), (folder.name, result)
        # Repeat the real post-fit setup stage; the saved proposal is the
        # refined result, not necessarily the initial automatic fit.
        second = cv2.imread(str(folder / 'setup/stability.png'))
        texts = json.loads((folder / 'setup/cell-text.json').read_text())
        first_text = next(item['masked'] for item in reversed(texts) if item['still'] == 'still')
        second_text = next(item['masked'] for item in reversed(texts) if item['still'] == 'stability')
        candidate, _ = refine_quad([(image, first_text.replace('?', ' '))], result.quad,
                                   LATTICE_GRID, DEFAULT_TARGET_SIZE)
        before = raster_offset_check([(second, second_text)], result.quad)
        after = raster_offset_check([(second, second_text)], candidate)
        refinement_applied = heldout_improves(before, after)
        if refinement_applied:
            result = evaluate_quad(image, hint, candidate, empty_cells=(8, 13, 14, 15))
            assert not isinstance(result, str), (folder.name, result)
        quad = np.asarray(result.quad)
        recorded_quad = np.asarray(proposal['quad'])
        max_corner_difference = float(np.linalg.norm(quad - recorded_quad, axis=1).max())
        assert max_corner_difference <= 1.5, (folder.name, max_corner_difference)
        static = check_setup(image, result).to_dict()
        assert static['checks']['kanten']['status'] != 'FEHLER'
        tracking = proposal['live_tracking']['proposal']
        config = FrameTrackingConfig.from_dict(proposal['live_tracking']['config'])
        q = np.asarray(tracking['normalised_quad'], dtype=float)
        outer = np.asarray(tracking['outer_limit'], dtype=float)
        centres = np.asarray([r['centre'] for r in tracking['regions']], dtype=float)
        local = (centres - q.mean(axis=0)) @ _axes(q).T
        limits = _proposal_spread_limits(q, outer, config)
        side_counts = np.array([(local <= -limits[0]).sum(axis=0), (local >= limits[1]).sum(axis=0)])
        spread = bool(np.all(side_counts >= config.min_inliers_per_side))
        reserve = _reserve_ok(centres, q, config, limits)
        assert spread and reserve
        reading = diagnose_reader([(image, first_text), (second, second_text)], result.quad,
                                   root / 'reference-assets/var/dotmatrix/templates-stufe2c-2026-09-30.json',
                                   '6f20dec4f558e98be41203d0ab48eb4788d16e02c1350313a740c25cc03f693a',
                                   reference_kind='seriell')
        assert reading.status == 'OK', (folder.name, reading.to_dict())
        print(json.dumps({'operation': 'positive_setup', 'session_id': folder.name,
                          'fit': 'ok', 'max_corner_difference_px': max_corner_difference,
                          'recorded_overall': proposal['setup_checks']['overall'],
                          'regions_per_axis_side': side_counts.tolist(), 'spread_ok': spread,
                          'reserve_ok': reserve, 'temporal_stability_replayed': False}), flush=True)
    if args.historical_controls:
        env = dict(os.environ, DISPREAD_DEV_DATA=str(root / 'historical-controls'))
        subprocess.run([sys.executable, '-m', 'pytest', '-q', '-c', str(source / 'pyproject.toml'),
                        str(source / 'tests/test_dotlattice.py'), '-k', 'test_real_still_matches_confirmed_quad'],
                       env=env, check=True)
