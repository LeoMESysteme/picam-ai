"""Read-only replay of the archived 2026-11-11 setup evidence; no camera access."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import tarfile
import tempfile
import threading
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def verify():
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    expected = {item['path'] for item in manifest['files']}
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and p.name != 'MANIFEST.json'}
    if actual != expected:
        raise ValueError(f'Unexpected or missing files: {sorted(actual ^ expected)}')
    for item in manifest['files']:
        data = (ROOT / item['path']).read_bytes()
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise ValueError(f'Checksum mismatch: {item["path"]}')
    return len(expected)


def raster(case):
    import cv2
    from dispread.dotlattice import fit_lattice
    from dispread.setup_hint import find_green_hint_box

    folder = ROOT / 'sessions' / case['session_id'] / 'setup'
    image = cv2.imread(str(folder / 'still.png'))
    if image is None:
        raise ValueError(f'Cannot read image: {folder}')
    hint = find_green_hint_box(image)
    fit = None if hint is None else fit_lattice(image, hint, empty_cells=(8, 13, 14, 15))
    observed = 'no_green_hint' if hint is None else fit if isinstance(fit, str) else 'ok'
    result = {'session_id': case['session_id'], 'operation': 'fit_lattice',
              'hint_box': hint, 'image_shape': list(image.shape), 'observed': observed,
              'expected_baseline': case['expected_raster_result'],
              'baseline_matches': observed == case['expected_raster_result'],
              'time_claim': False}
    if observed == 'ok':
        result['fit'] = {'quad': fit.quad, 'n_dots': fit.n_dots,
                         'n_assigned': fit.n_assigned,
                         'rms_cols': fit.rms_cols, 'rms_rows': fit.rms_rows}
    return result


def tracking_geometry():
    import numpy as np
    from dispread.live.frame_tracking import (
        FrameTrackingConfig, _axes, _proposal_spread_limits, _reserve_ok,
    )

    session = 'live-20261111T155557Z'
    proposal = json.loads((ROOT / 'sessions' / session / 'setup/proposal.json').read_text())
    block = proposal['live_tracking']
    saved = block['proposal']
    config = FrameTrackingConfig.from_dict(block['config'])
    quad = np.asarray(saved['normalised_quad'], dtype=float)
    outer = np.asarray(saved['outer_limit'], dtype=float)
    centres = np.asarray([r['centre'] for r in saved['regions']], dtype=float)
    local = (centres - quad.mean(axis=0)) @ _axes(quad).T
    limits = _proposal_spread_limits(quad, outer, config)
    counts = np.asarray([(local <= -limits[0]).sum(axis=0),
                         (local >= limits[1]).sum(axis=0)])
    spread = bool(np.all(counts >= config.min_inliers_per_side))
    reserve = _reserve_ok(centres, quad, config, limits)
    metrics = saved['metrics']
    matches = (counts.tolist() == metrics['regions_per_axis_side']
               and spread == metrics['spread_ok'] and reserve == metrics['reserve_ok'])
    return {'session_id': session, 'operation': 'recorded_region_distribution',
            'regions': len(centres), 'regions_per_axis_side': counts.tolist(),
            'side_order': ['negative local x/y', 'positive local x/y'],
            'spread_ok': spread, 'reserve_ok': reserve,
            'required_per_side': config.min_inliers_per_side,
            'required_with_reserve': config.min_inliers_per_side + config.reserve_regions,
            'proposal_spread_limits_px': limits.tolist(), 'baseline_matches': matches,
            'temporal_stability_replayed': False,
            'limitation': 'The eight original stability samples were not persisted.',
            'time_claim': False}


def ui_dead_end(source):
    # Only pure view functions and precondition guards are executed.
    # No LiveService constructor, camera owner, setup worker or run is started.
    from dispread.live.service import LiveError, LiveService

    session = 'live-20261111T155557Z'
    proposal = json.loads((ROOT / 'sessions' / session / 'setup/proposal.json').read_text())
    status = json.loads((ROOT / 'live-status.json').read_text())['status']
    script = r'''
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const [confirmPath, shellPath] = process.argv.slice(1);
const code = readFileSync(confirmPath, 'utf8');
const {confirmModel, fieldsReady} = await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));
let raw = '';
for await (const chunk of process.stdin) raw += chunk;
const status = JSON.parse(raw);
const shell = readFileSync(shellPath, 'utf8');
const start = shell.indexOf('function titleActions(');
const end = shell.indexOf('\nfunction actionHTML(', start);
if (start < 0 || end < 0) throw new Error('Historical titleActions not found');
const titleActions = vm.runInNewContext('(' + shell.slice(start, end) + ')');
const ready = fieldsReady(confirmModel(status), {name: 'Offline evidence', format: true, ack: true});
const actions = titleActions(status, {busy: false, canConfirm: ready},
    {setup() {}, cancelSetup() {}, confirm() {}});
console.log(JSON.stringify({fields_ready: ready,
    actions: actions.map(a => ({name: a.name || a.kind, label: a.label, disabled: a.disabled}))}));
'''
    base = source / 'src/dispread/workbench/static/live'
    process = subprocess.run(
        ['node', '--input-type=module', '-e', script,
         str(base / 'setup/confirm.js'), str(base / 'shell.js')],
        input=json.dumps(status), text=True, capture_output=True, check=True,
    )
    view = json.loads(process.stdout)
    service = object.__new__(LiveService)
    service._lock = threading.Lock()
    service._operation_lock = threading.Lock()
    service._state = 'setup_ready'
    service._proposal = proposal
    service._session_dir = Path(session)
    errors = {}
    try:
        service.confirm(session_id=session, confirmed_by='Offline evidence', format_checked=True,
                        proposal_revision=proposal['live_tracking']['proposal_revision'])
    except LiveError as error:
        errors['confirm'] = str(error)
    try:
        service.cancel_setup()
    except LiveError as error:
        errors['cancel'] = str(error)
    names = [a['name'] for a in view['actions']]
    matches = (view['fields_ready'] and names == ['confirm']
               and 'FEHLER' in errors.get('confirm', '')
               and errors.get('cancel') == 'Keine Einrichtung laeuft')
    return {'session_id': session, 'operation': 'setup_ready_error_dead_end',
            'priority': 'high', 'view': view, 'backend_errors': errors,
            'state_after_rejected_actions': service._state,
            'baseline_matches': matches, 'hardware_access': False,
            'browser_screenshot': False,
            'scope': 'Historical pure UI action model and actual service guards; no hardware or HTTP call.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raster', action='store_true', help='Replay still-image raster fits (can take minutes).')
    parser.add_argument('--tracking', action='store_true', help='Replay the saved geometric distribution gate only.')
    parser.add_argument('--ui', action='store_true', help='Replay the reported UI dead end and service guards (needs Node.js).')
    parser.add_argument('--case', action='append', help='Select session IDs for raster replay; repeatable.')
    parser.add_argument('--source', type=Path, help='Use another checkout for comparison instead of the frozen source.')
    args = parser.parse_args()
    count = verify()
    print(json.dumps({'verified_files': count, 'hardware_access': False}), flush=True)
    if not args.raster and not args.tracking and not args.ui:
        return 0
    case_data = json.loads((ROOT / 'cases.json').read_text())
    selected = [c for c in case_data if c.get('expected_raster_result') is not None
                and (not args.case or c['session_id'] in args.case)]
    if args.case and set(args.case) - {c['session_id'] for c in selected}:
        raise ValueError('Unknown case or no raster evidence for the selected case.')
    results = []
    with tempfile.TemporaryDirectory(prefix='dispread-setup-replay-') as temporary:
        if args.source:
            source = args.source.resolve()
        else:
            with tarfile.open(ROOT / 'source-08ac9b9.tar.gz', 'r:gz') as archive:
                archive.extractall(temporary, filter='data')
            source = Path(temporary) / 'source'
        if not (source / 'src/dispread/dotlattice.py').is_file():
            raise ValueError(f'Invalid source checkout: {source}')
        sys.path.insert(0, str(source / 'src'))
        if args.raster:
            for case in selected:
                print(json.dumps({'starting_case': case['session_id']}), flush=True)
                result = raster(case)
                print(json.dumps(result, ensure_ascii=False), flush=True)
                results.append(result)
        if args.tracking:
            result = tracking_geometry()
            print(json.dumps(result, ensure_ascii=False), flush=True)
            results.append(result)
        if args.ui:
            result = ui_dead_end(source)
            print(json.dumps(result, ensure_ascii=False), flush=True)
            results.append(result)
    # When comparing a fix, a changed outcome is expected; never call that acceptance.
    return 0 if args.source or all(r['baseline_matches'] for r in results) else 2


if __name__ == '__main__':
    raise SystemExit(main())
